﻿namespace Card_Identifier
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelInstructions = new System.Windows.Forms.Label();
            this.labelDisplayCard = new System.Windows.Forms.Label();
            this.buttonExit = new System.Windows.Forms.Button();
            this.pictureCard5 = new System.Windows.Forms.PictureBox();
            this.pictureCard4 = new System.Windows.Forms.PictureBox();
            this.pictureCard3 = new System.Windows.Forms.PictureBox();
            this.pictureCard2 = new System.Windows.Forms.PictureBox();
            this.pictureCard1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureCard5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureCard4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureCard3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureCard2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureCard1)).BeginInit();
            this.SuspendLayout();
            // 
            // labelInstructions
            // 
            this.labelInstructions.AutoSize = true;
            this.labelInstructions.Location = new System.Drawing.Point(73, 25);
            this.labelInstructions.Name = "labelInstructions";
            this.labelInstructions.Size = new System.Drawing.Size(143, 13);
            this.labelInstructions.TabIndex = 0;
            this.labelInstructions.Text = "Click a Card to See Its Name";
            // 
            // labelDisplayCard
            // 
            this.labelDisplayCard.BackColor = System.Drawing.SystemColors.ControlDark;
            this.labelDisplayCard.Location = new System.Drawing.Point(181, 174);
            this.labelDisplayCard.Name = "labelDisplayCard";
            this.labelDisplayCard.Size = new System.Drawing.Size(100, 23);
            this.labelDisplayCard.TabIndex = 1;
            this.labelDisplayCard.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // buttonExit
            // 
            this.buttonExit.Location = new System.Drawing.Point(184, 230);
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.Size = new System.Drawing.Size(75, 23);
            this.buttonExit.TabIndex = 2;
            this.buttonExit.Text = "Exit";
            this.buttonExit.UseVisualStyleBackColor = true;
            this.buttonExit.Click += new System.EventHandler(this.buttonExit_Click);
            // 
            // pictureCard5
            // 
            this.pictureCard5.Image = global::Card_Identifier.Properties.Resources._8_Hearts;
            this.pictureCard5.Location = new System.Drawing.Point(313, 62);
            this.pictureCard5.Name = "pictureCard5";
            this.pictureCard5.Size = new System.Drawing.Size(69, 96);
            this.pictureCard5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureCard5.TabIndex = 7;
            this.pictureCard5.TabStop = false;
            this.pictureCard5.Click += new System.EventHandler(this.pictureCard5_Click);
            // 
            // pictureCard4
            // 
            this.pictureCard4.Image = global::Card_Identifier.Properties.Resources.Ace_Spades;
            this.pictureCard4.Location = new System.Drawing.Point(237, 62);
            this.pictureCard4.Name = "pictureCard4";
            this.pictureCard4.Size = new System.Drawing.Size(69, 96);
            this.pictureCard4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureCard4.TabIndex = 6;
            this.pictureCard4.TabStop = false;
            this.pictureCard4.Click += new System.EventHandler(this.pictureCard4_Click);
            // 
            // pictureCard3
            // 
            this.pictureCard3.Image = global::Card_Identifier.Properties.Resources.Joker_Red;
            this.pictureCard3.Location = new System.Drawing.Point(162, 62);
            this.pictureCard3.Name = "pictureCard3";
            this.pictureCard3.Size = new System.Drawing.Size(69, 96);
            this.pictureCard3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureCard3.TabIndex = 5;
            this.pictureCard3.TabStop = false;
            this.pictureCard3.Click += new System.EventHandler(this.pictureCard3_Click);
            // 
            // pictureCard2
            // 
            this.pictureCard2.Image = global::Card_Identifier.Properties.Resources.Jack_Spades;
            this.pictureCard2.Location = new System.Drawing.Point(87, 62);
            this.pictureCard2.Name = "pictureCard2";
            this.pictureCard2.Size = new System.Drawing.Size(69, 96);
            this.pictureCard2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureCard2.TabIndex = 4;
            this.pictureCard2.TabStop = false;
            this.pictureCard2.Click += new System.EventHandler(this.pictureCard2_Click);
            // 
            // pictureCard1
            // 
            this.pictureCard1.Image = global::Card_Identifier.Properties.Resources._6_Clubs;
            this.pictureCard1.Location = new System.Drawing.Point(12, 62);
            this.pictureCard1.Name = "pictureCard1";
            this.pictureCard1.Size = new System.Drawing.Size(69, 96);
            this.pictureCard1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureCard1.TabIndex = 3;
            this.pictureCard1.TabStop = false;
            this.pictureCard1.Click += new System.EventHandler(this.pictureCard1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(571, 269);
            this.Controls.Add(this.pictureCard5);
            this.Controls.Add(this.pictureCard4);
            this.Controls.Add(this.pictureCard3);
            this.Controls.Add(this.pictureCard2);
            this.Controls.Add(this.pictureCard1);
            this.Controls.Add(this.buttonExit);
            this.Controls.Add(this.labelDisplayCard);
            this.Controls.Add(this.labelInstructions);
            this.Name = "Form1";
            this.Text = "Card Identifier";
            ((System.ComponentModel.ISupportInitialize)(this.pictureCard5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureCard4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureCard3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureCard2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureCard1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelInstructions;
        private System.Windows.Forms.Label labelDisplayCard;
        private System.Windows.Forms.Button buttonExit;
        private System.Windows.Forms.PictureBox pictureCard1;
        private System.Windows.Forms.PictureBox pictureCard2;
        private System.Windows.Forms.PictureBox pictureCard3;
        private System.Windows.Forms.PictureBox pictureCard4;
        private System.Windows.Forms.PictureBox pictureCard5;
    }
}

