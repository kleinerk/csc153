﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Card_Identifier
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void pictureCard1_Click(object sender, EventArgs e)
        {
            labelDisplayCard.Text = "Six of Clubs";
        }

        private void pictureCard2_Click(object sender, EventArgs e)
        {
            labelDisplayCard.Text = "Jack of Spades";
        }

        private void pictureCard3_Click(object sender, EventArgs e)
        {
            labelDisplayCard.Text = "Red Joker";
        }

        private void pictureCard4_Click(object sender, EventArgs e)
        {
            labelDisplayCard.Text = "Ace of Spades";
        }

        private void pictureCard5_Click(object sender, EventArgs e)
        {
            labelDisplayCard.Text = "Eight of Hearts";
        }
    }
}
