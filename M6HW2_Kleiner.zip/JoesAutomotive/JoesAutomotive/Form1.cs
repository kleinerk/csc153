﻿/*
* 10 April 2018
* CSC 153
* Kenneth Kleiner
* This program overly uses methods so that students can learn about methods.
* Not the way I would have done it.
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace JoesAutomotive
{
    public partial class Form1 : Form
    {
        decimal OL_Charges = 0.00m;
        decimal F_charges = 0.00m;
        decimal M_charges = 0.00m;
        decimal O_charges = 0.00m;
        decimal taxValue = 0.00m;
        decimal laborValue = 0.00m;
        decimal partsValue = 0.00m;
        decimal otherValue = 0.00m;
        decimal serviceCharges = 0.00m;
        decimal totalChargeValue = 0.00m;

        public Form1()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            ClearOilLube();
            ClearFlushes();
            ClearMisc();
            ClearOther();
            ClearFees();
            taxValue = 0;
            laborValue = 0;
            partsValue = 0;
            otherValue = 0;
            serviceCharges = 0;
            totalChargeValue = 0;
        }

        private void ClearOilLube()
        {
            oilChangeCheckBox.Checked = false;
            lubeJobCheckBox.Checked = false;
        }
        private void ClearFlushes()
        {
            RadiatorFlushCheckBox.Checked = false;
            tranmisssionFlushCheckBox.Checked = false;
        }
        private void ClearMisc()
        {
            inspectionCheckBox.Checked = false;
            replaceMufflerCheckBox.Checked = false;
            tireRotationCheckBox.Checked = false;
        }
        private void ClearOther()
        {
            partsTextBox.Text = "";
            laborTextBox.Text = "";
        }
        private void ClearFees()
        {
            serviceLaborValueLabel.Text = "";
            summaryPartsValueLabel.Text = "";
            summaryTaxLabel.Text = "";
            totalFeesValueLabel.Text = "";
        }
        private int OilLubeCharges()
        {
            int oilLubeValue = 0;
            if (oilChangeCheckBox.Checked)
                oilLubeValue += 26;
            if (lubeJobCheckBox.Checked)
                oilLubeValue += 18;
            return oilLubeValue;
        }
        private int FlushCharges()
        {
            int flushesValue = 0;
            if (RadiatorFlushCheckBox.Checked)
                flushesValue += 30;
            if (tranmisssionFlushCheckBox.Checked)
                flushesValue += 80;
            return flushesValue;
        }
        private int MiscCharges()
        {
            int miscValue = 0;
            if (inspectionCheckBox.Checked)
                miscValue += 15;
            if (replaceMufflerCheckBox.Checked)
                miscValue += 100;
            if (tireRotationCheckBox.Checked)
                miscValue += 20;
            return miscValue;
        }
        private decimal OtherCharges()
        {
                        
            if (partsTextBox.Text != "")
            {
                partsValue += decimal.Parse(partsTextBox.Text);
                taxValue = TaxCharges(partsValue);
                summaryTaxLabel.Text = taxValue.ToString();
            }
            if (laborTextBox.Text != "")
                laborValue += decimal.Parse(laborTextBox.Text);
            otherValue = partsValue + laborValue;
            return otherValue;
        }
        private decimal TaxCharges(decimal partsValue)
        {
            decimal taxValue = 0;
            taxValue = partsValue * 0.07m;
            return taxValue;
        }
        private decimal TotalCharges()
        {

            OL_Charges = OilLubeCharges();
            F_charges = FlushCharges();
            M_charges = MiscCharges();
            O_charges = OtherCharges();

            totalChargeValue = OL_Charges + F_charges + M_charges + O_charges + taxValue;
            return totalChargeValue;
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            totalChargeValue = TotalCharges();

            serviceCharges = OL_Charges + F_charges + M_charges + laborValue;
            serviceLaborValueLabel.Text = serviceCharges.ToString();

            summaryPartsValueLabel.Text = partsValue.ToString();

            summaryTaxLabel.Text = taxValue.ToString();

            totalFeesValueLabel.Text = totalChargeValue.ToString();
            
        }
    }
}
