﻿/*
* 27 March 2018
* CSC 153
* Kenneth Kleiner
* Program that introduces using a method and accepts time and displays distance that it would fall in a vacuum.
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FallingDistance
{
    public partial class Form1 : Form
    {
        // constants and variables for class
        private const double GRAVITY = 9.8;
        double distance;
        public Form1()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // close form
            this.Close();
        }

        // method to calculate distance   d=1/2gt^2
        private void FallingDistance(double t)
        {
            // original calculation
            // distance = (GRAVITY * (t*t))/2;

            // updated formula to use math
            distance = (GRAVITY * Math.Pow(t, 2)/2);
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            // get time object is falling
            double timeEntered = double.Parse(timeTextBox.Text);
            // call method sending time
            FallingDistance(timeEntered);
            // display result of calculation
            distanceLabel.Text = "In " + timeEntered + " second(s), an object will fall " + distance.ToString() + " meters";
        }
    }
}
