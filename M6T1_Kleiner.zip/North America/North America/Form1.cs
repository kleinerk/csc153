﻿/*
* 10 April 2018
* CSC 153
* Kenneth Kleiner
* This program takes input from a file and adds information to a listbox
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace North_America
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // The GetFileName method gets a filename from the
        // user and assigns it to the variable passed as
        // an argument.

        private void GetFileName(out string selectedFile)
        {
            if (openFile.ShowDialog() == DialogResult.OK)
            {
                selectedFile = openFile.FileName;
            }
            else
            {
                selectedFile = "";
            }
        }

        // The GetCountries method accepts a filename as an
        // argument.  It opens the specified file and displays
        // its contents in the countriesListBox control.
        private void GetCountries(string filename)
        {
            try
            {
                // declare a variable to hold a country name
                string countryName;

                // declare a StreamReader variable
                StreamReader inputFile;

                // open the file and get a StreamReader object
                inputFile = File.OpenText(filename);

                // clear anything currently in the ListBox
                countriesListBox.Items.Clear();

                // read the file's contents
                while(!inputFile.EndOfStream)
                {
                    // get a country name
                    countryName = inputFile.ReadLine();

                    // add the country name to the ListBox
                    countriesListBox.Items.Add(countryName);
                }
                // close the file
                inputFile.Close();
            }
            catch (Exception ex)
            {
                // display an error message
                MessageBox.Show(ex.Message);
            }
        }

        private void getCountriesButton_Click(object sender, EventArgs e)
        {
            string filename;   // to hold the filename

            // Get the filename from the user
            GetFileName(out filename);

            // Get the countries from the file
            GetCountries(filename);
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Close the form
            this.Close();
        }
    }
}
