﻿/*
* 3 May 2018
* CSC 153
* Kenneth Kleiner
* Introduction to Multiform Project
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _9_6_Dorm
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            int totalCost = 0;

            if (allenRadioButton.Checked)
            {
                totalCost += 1500;
            }
            else if (pikeRadioButton.Checked)
            {
                totalCost += 1600;
            }
            else if (farthingRadioButton.Checked)
            {
                totalCost += 1800;
            }
            else
            {
                totalCost += 2500;
            }

            if (mp7_RadioButton.Checked)
            {
                totalCost += 600;
            }
            else if (mp14_RadioButton.Checked)
            {
                totalCost += 1200;
            }
            else
            {
                totalCost += 1700;
            }

            DisplayForm myDisplayForm = new DisplayForm();

            myDisplayForm.costDisplayLabel.Text = totalCost.ToString("c");
            myDisplayForm.ShowDialog();
        }
    }
}
