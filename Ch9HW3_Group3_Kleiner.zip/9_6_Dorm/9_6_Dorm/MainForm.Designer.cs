﻿namespace _9_6_Dorm
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dormitoryGroupBox = new System.Windows.Forms.GroupBox();
            this.mealPlanGroupBox = new System.Windows.Forms.GroupBox();
            this.allenRadioButton = new System.Windows.Forms.RadioButton();
            this.pikeRadioButton = new System.Windows.Forms.RadioButton();
            this.farthingRadioButton = new System.Windows.Forms.RadioButton();
            this.universityRadioButton = new System.Windows.Forms.RadioButton();
            this.mp7_RadioButton = new System.Windows.Forms.RadioButton();
            this.mp14_RadioButton = new System.Windows.Forms.RadioButton();
            this.mpUnlimited_RadioButton = new System.Windows.Forms.RadioButton();
            this.calculateButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.dormitoryGroupBox.SuspendLayout();
            this.mealPlanGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // dormitoryGroupBox
            // 
            this.dormitoryGroupBox.Controls.Add(this.universityRadioButton);
            this.dormitoryGroupBox.Controls.Add(this.farthingRadioButton);
            this.dormitoryGroupBox.Controls.Add(this.pikeRadioButton);
            this.dormitoryGroupBox.Controls.Add(this.allenRadioButton);
            this.dormitoryGroupBox.Location = new System.Drawing.Point(42, 40);
            this.dormitoryGroupBox.Name = "dormitoryGroupBox";
            this.dormitoryGroupBox.Size = new System.Drawing.Size(200, 129);
            this.dormitoryGroupBox.TabIndex = 0;
            this.dormitoryGroupBox.TabStop = false;
            this.dormitoryGroupBox.Text = "Dormitory Choice";
            // 
            // mealPlanGroupBox
            // 
            this.mealPlanGroupBox.Controls.Add(this.mpUnlimited_RadioButton);
            this.mealPlanGroupBox.Controls.Add(this.mp14_RadioButton);
            this.mealPlanGroupBox.Controls.Add(this.mp7_RadioButton);
            this.mealPlanGroupBox.Location = new System.Drawing.Point(280, 40);
            this.mealPlanGroupBox.Name = "mealPlanGroupBox";
            this.mealPlanGroupBox.Size = new System.Drawing.Size(216, 100);
            this.mealPlanGroupBox.TabIndex = 1;
            this.mealPlanGroupBox.TabStop = false;
            this.mealPlanGroupBox.Text = "Meal Plan Choice";
            // 
            // allenRadioButton
            // 
            this.allenRadioButton.AutoSize = true;
            this.allenRadioButton.Checked = true;
            this.allenRadioButton.Location = new System.Drawing.Point(7, 20);
            this.allenRadioButton.Name = "allenRadioButton";
            this.allenRadioButton.Size = new System.Drawing.Size(158, 17);
            this.allenRadioButton.TabIndex = 0;
            this.allenRadioButton.TabStop = true;
            this.allenRadioButton.Text = "Allen Hall ($1,500/semester)";
            this.allenRadioButton.UseVisualStyleBackColor = true;
            // 
            // pikeRadioButton
            // 
            this.pikeRadioButton.AutoSize = true;
            this.pikeRadioButton.Location = new System.Drawing.Point(7, 44);
            this.pikeRadioButton.Name = "pikeRadioButton";
            this.pikeRadioButton.Size = new System.Drawing.Size(156, 17);
            this.pikeRadioButton.TabIndex = 1;
            this.pikeRadioButton.Text = "Pike Hall ($1,600/semester)";
            this.pikeRadioButton.UseVisualStyleBackColor = true;
            // 
            // farthingRadioButton
            // 
            this.farthingRadioButton.AutoSize = true;
            this.farthingRadioButton.Location = new System.Drawing.Point(7, 68);
            this.farthingRadioButton.Name = "farthingRadioButton";
            this.farthingRadioButton.Size = new System.Drawing.Size(173, 17);
            this.farthingRadioButton.TabIndex = 2;
            this.farthingRadioButton.Text = "Farthing Hall ($1,800/semester)";
            this.farthingRadioButton.UseVisualStyleBackColor = true;
            // 
            // universityRadioButton
            // 
            this.universityRadioButton.AutoSize = true;
            this.universityRadioButton.Location = new System.Drawing.Point(7, 92);
            this.universityRadioButton.Name = "universityRadioButton";
            this.universityRadioButton.Size = new System.Drawing.Size(192, 17);
            this.universityRadioButton.TabIndex = 3;
            this.universityRadioButton.Text = "University Suites ($2,500/semester)";
            this.universityRadioButton.UseVisualStyleBackColor = true;
            // 
            // mp7_RadioButton
            // 
            this.mp7_RadioButton.AutoSize = true;
            this.mp7_RadioButton.Checked = true;
            this.mp7_RadioButton.Location = new System.Drawing.Point(7, 20);
            this.mp7_RadioButton.Name = "mp7_RadioButton";
            this.mp7_RadioButton.Size = new System.Drawing.Size(191, 17);
            this.mp7_RadioButton.TabIndex = 0;
            this.mp7_RadioButton.TabStop = true;
            this.mp7_RadioButton.Text = "7 meals per week ($ 600/semester)";
            this.mp7_RadioButton.UseVisualStyleBackColor = true;
            // 
            // mp14_RadioButton
            // 
            this.mp14_RadioButton.AutoSize = true;
            this.mp14_RadioButton.Location = new System.Drawing.Point(7, 44);
            this.mp14_RadioButton.Name = "mp14_RadioButton";
            this.mp14_RadioButton.Size = new System.Drawing.Size(203, 17);
            this.mp14_RadioButton.TabIndex = 1;
            this.mp14_RadioButton.Text = "14 meals per week ($1,200/semester)";
            this.mp14_RadioButton.UseVisualStyleBackColor = true;
            // 
            // mpUnlimited_RadioButton
            // 
            this.mpUnlimited_RadioButton.AutoSize = true;
            this.mpUnlimited_RadioButton.Location = new System.Drawing.Point(7, 68);
            this.mpUnlimited_RadioButton.Name = "mpUnlimited_RadioButton";
            this.mpUnlimited_RadioButton.Size = new System.Drawing.Size(188, 17);
            this.mpUnlimited_RadioButton.TabIndex = 2;
            this.mpUnlimited_RadioButton.Text = "Unlimited Meals ($1,700/semester)";
            this.mpUnlimited_RadioButton.UseVisualStyleBackColor = true;
            // 
            // calculateButton
            // 
            this.calculateButton.Location = new System.Drawing.Point(42, 189);
            this.calculateButton.Name = "calculateButton";
            this.calculateButton.Size = new System.Drawing.Size(199, 23);
            this.calculateButton.TabIndex = 2;
            this.calculateButton.Text = "Calculate cost per semester";
            this.calculateButton.UseVisualStyleBackColor = true;
            this.calculateButton.Click += new System.EventHandler(this.calculateButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(421, 189);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 3;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(526, 239);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.calculateButton);
            this.Controls.Add(this.mealPlanGroupBox);
            this.Controls.Add(this.dormitoryGroupBox);
            this.Name = "MainForm";
            this.Text = "Dorm/Meal Planner";
            this.dormitoryGroupBox.ResumeLayout(false);
            this.dormitoryGroupBox.PerformLayout();
            this.mealPlanGroupBox.ResumeLayout(false);
            this.mealPlanGroupBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox dormitoryGroupBox;
        private System.Windows.Forms.RadioButton universityRadioButton;
        private System.Windows.Forms.RadioButton farthingRadioButton;
        private System.Windows.Forms.RadioButton pikeRadioButton;
        private System.Windows.Forms.RadioButton allenRadioButton;
        private System.Windows.Forms.GroupBox mealPlanGroupBox;
        private System.Windows.Forms.RadioButton mpUnlimited_RadioButton;
        private System.Windows.Forms.RadioButton mp14_RadioButton;
        private System.Windows.Forms.RadioButton mp7_RadioButton;
        private System.Windows.Forms.Button calculateButton;
        private System.Windows.Forms.Button exitButton;
    }
}

