﻿namespace Workshop_Selector
{
    partial class workshopForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.workshopChoicePanel = new System.Windows.Forms.Panel();
            this.interviewCostLabel = new System.Windows.Forms.Label();
            this.negotiationCostLabel = new System.Windows.Forms.Label();
            this.supervisionCostLabel = new System.Windows.Forms.Label();
            this.timeCostLabel = new System.Windows.Forms.Label();
            this.stressCostLabel = new System.Windows.Forms.Label();
            this.interviewDaysLabel = new System.Windows.Forms.Label();
            this.negotiationDaysLabel = new System.Windows.Forms.Label();
            this.supervisionDaysLabel = new System.Windows.Forms.Label();
            this.timeDaysLabel = new System.Windows.Forms.Label();
            this.workshopCostLabel = new System.Windows.Forms.Label();
            this.workshopDaysLlabel = new System.Windows.Forms.Label();
            this.workshopNameLabel = new System.Windows.Forms.Label();
            this.stressDaysLabel = new System.Windows.Forms.Label();
            this.interviewRadioButton = new System.Windows.Forms.RadioButton();
            this.negotiationRadioButton = new System.Windows.Forms.RadioButton();
            this.supervisionRadioButton = new System.Windows.Forms.RadioButton();
            this.timeRadioButton = new System.Windows.Forms.RadioButton();
            this.stressRadioButton = new System.Windows.Forms.RadioButton();
            this.locationPanel = new System.Windows.Forms.Panel();
            this.austinLodgingLabel = new System.Windows.Forms.Label();
            this.costPerDayLabel = new System.Windows.Forms.Label();
            this.locationLabel = new System.Windows.Forms.Label();
            this.raleighRadioButton = new System.Windows.Forms.RadioButton();
            this.phoenixRadioButton = new System.Windows.Forms.RadioButton();
            this.orlandoRadioButton = new System.Windows.Forms.RadioButton();
            this.dallasRadioButton = new System.Windows.Forms.RadioButton();
            this.chicagoRadioButton = new System.Windows.Forms.RadioButton();
            this.austinRadioButton = new System.Windows.Forms.RadioButton();
            this.chicagoLodgingLabel = new System.Windows.Forms.Label();
            this.dallasLodgingLabel = new System.Windows.Forms.Label();
            this.orlandoLodgingLabel = new System.Windows.Forms.Label();
            this.phoenixLodgingLabel = new System.Windows.Forms.Label();
            this.raleighLodgingLabel = new System.Windows.Forms.Label();
            this.exitButton = new System.Windows.Forms.Button();
            this.calculateButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.totalCostLabel = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.workshopChoicePanel.SuspendLayout();
            this.locationPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // workshopChoicePanel
            // 
            this.workshopChoicePanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.workshopChoicePanel.Controls.Add(this.interviewCostLabel);
            this.workshopChoicePanel.Controls.Add(this.negotiationCostLabel);
            this.workshopChoicePanel.Controls.Add(this.supervisionCostLabel);
            this.workshopChoicePanel.Controls.Add(this.timeCostLabel);
            this.workshopChoicePanel.Controls.Add(this.stressCostLabel);
            this.workshopChoicePanel.Controls.Add(this.interviewDaysLabel);
            this.workshopChoicePanel.Controls.Add(this.negotiationDaysLabel);
            this.workshopChoicePanel.Controls.Add(this.supervisionDaysLabel);
            this.workshopChoicePanel.Controls.Add(this.timeDaysLabel);
            this.workshopChoicePanel.Controls.Add(this.workshopCostLabel);
            this.workshopChoicePanel.Controls.Add(this.workshopDaysLlabel);
            this.workshopChoicePanel.Controls.Add(this.workshopNameLabel);
            this.workshopChoicePanel.Controls.Add(this.stressDaysLabel);
            this.workshopChoicePanel.Controls.Add(this.interviewRadioButton);
            this.workshopChoicePanel.Controls.Add(this.negotiationRadioButton);
            this.workshopChoicePanel.Controls.Add(this.supervisionRadioButton);
            this.workshopChoicePanel.Controls.Add(this.timeRadioButton);
            this.workshopChoicePanel.Controls.Add(this.stressRadioButton);
            this.workshopChoicePanel.Location = new System.Drawing.Point(59, 69);
            this.workshopChoicePanel.Name = "workshopChoicePanel";
            this.workshopChoicePanel.Size = new System.Drawing.Size(335, 183);
            this.workshopChoicePanel.TabIndex = 0;
            // 
            // interviewCostLabel
            // 
            this.interviewCostLabel.AutoSize = true;
            this.interviewCostLabel.Location = new System.Drawing.Point(263, 149);
            this.interviewCostLabel.Name = "interviewCostLabel";
            this.interviewCostLabel.Size = new System.Drawing.Size(31, 13);
            this.interviewCostLabel.TabIndex = 17;
            this.interviewCostLabel.Text = "$500";
            // 
            // negotiationCostLabel
            // 
            this.negotiationCostLabel.AutoSize = true;
            this.negotiationCostLabel.Location = new System.Drawing.Point(254, 125);
            this.negotiationCostLabel.Name = "negotiationCostLabel";
            this.negotiationCostLabel.Size = new System.Drawing.Size(40, 13);
            this.negotiationCostLabel.TabIndex = 16;
            this.negotiationCostLabel.Text = "$1,300";
            // 
            // supervisionCostLabel
            // 
            this.supervisionCostLabel.AutoSize = true;
            this.supervisionCostLabel.Location = new System.Drawing.Point(254, 101);
            this.supervisionCostLabel.Name = "supervisionCostLabel";
            this.supervisionCostLabel.Size = new System.Drawing.Size(40, 13);
            this.supervisionCostLabel.TabIndex = 15;
            this.supervisionCostLabel.Text = "$1,500";
            // 
            // timeCostLabel
            // 
            this.timeCostLabel.AutoSize = true;
            this.timeCostLabel.Location = new System.Drawing.Point(263, 77);
            this.timeCostLabel.Name = "timeCostLabel";
            this.timeCostLabel.Size = new System.Drawing.Size(31, 13);
            this.timeCostLabel.TabIndex = 14;
            this.timeCostLabel.Text = "$800";
            // 
            // stressCostLabel
            // 
            this.stressCostLabel.AutoSize = true;
            this.stressCostLabel.Location = new System.Drawing.Point(254, 53);
            this.stressCostLabel.Name = "stressCostLabel";
            this.stressCostLabel.Size = new System.Drawing.Size(40, 13);
            this.stressCostLabel.TabIndex = 13;
            this.stressCostLabel.Text = "$1,000";
            // 
            // interviewDaysLabel
            // 
            this.interviewDaysLabel.AutoSize = true;
            this.interviewDaysLabel.Location = new System.Drawing.Point(161, 149);
            this.interviewDaysLabel.Name = "interviewDaysLabel";
            this.interviewDaysLabel.Size = new System.Drawing.Size(13, 13);
            this.interviewDaysLabel.TabIndex = 12;
            this.interviewDaysLabel.Text = "1";
            // 
            // negotiationDaysLabel
            // 
            this.negotiationDaysLabel.AutoSize = true;
            this.negotiationDaysLabel.Location = new System.Drawing.Point(161, 125);
            this.negotiationDaysLabel.Name = "negotiationDaysLabel";
            this.negotiationDaysLabel.Size = new System.Drawing.Size(13, 13);
            this.negotiationDaysLabel.TabIndex = 11;
            this.negotiationDaysLabel.Text = "5";
            // 
            // supervisionDaysLabel
            // 
            this.supervisionDaysLabel.AutoSize = true;
            this.supervisionDaysLabel.Location = new System.Drawing.Point(161, 101);
            this.supervisionDaysLabel.Name = "supervisionDaysLabel";
            this.supervisionDaysLabel.Size = new System.Drawing.Size(13, 13);
            this.supervisionDaysLabel.TabIndex = 10;
            this.supervisionDaysLabel.Text = "3";
            // 
            // timeDaysLabel
            // 
            this.timeDaysLabel.AutoSize = true;
            this.timeDaysLabel.Location = new System.Drawing.Point(161, 77);
            this.timeDaysLabel.Name = "timeDaysLabel";
            this.timeDaysLabel.Size = new System.Drawing.Size(13, 13);
            this.timeDaysLabel.TabIndex = 9;
            this.timeDaysLabel.Text = "3";
            // 
            // workshopCostLabel
            // 
            this.workshopCostLabel.AutoSize = true;
            this.workshopCostLabel.Location = new System.Drawing.Point(238, 18);
            this.workshopCostLabel.Name = "workshopCostLabel";
            this.workshopCostLabel.Size = new System.Drawing.Size(84, 13);
            this.workshopCostLabel.TabIndex = 8;
            this.workshopCostLabel.Text = "Registration Fee";
            // 
            // workshopDaysLlabel
            // 
            this.workshopDaysLlabel.AutoSize = true;
            this.workshopDaysLlabel.Location = new System.Drawing.Point(123, 18);
            this.workshopDaysLlabel.Name = "workshopDaysLlabel";
            this.workshopDaysLlabel.Size = new System.Drawing.Size(83, 13);
            this.workshopDaysLlabel.TabIndex = 7;
            this.workshopDaysLlabel.Text = "Number of Days";
            // 
            // workshopNameLabel
            // 
            this.workshopNameLabel.AutoSize = true;
            this.workshopNameLabel.Location = new System.Drawing.Point(23, 18);
            this.workshopNameLabel.Name = "workshopNameLabel";
            this.workshopNameLabel.Size = new System.Drawing.Size(56, 13);
            this.workshopNameLabel.TabIndex = 6;
            this.workshopNameLabel.Text = "Workshop";
            // 
            // stressDaysLabel
            // 
            this.stressDaysLabel.AutoSize = true;
            this.stressDaysLabel.Location = new System.Drawing.Point(161, 53);
            this.stressDaysLabel.Name = "stressDaysLabel";
            this.stressDaysLabel.Size = new System.Drawing.Size(13, 13);
            this.stressDaysLabel.TabIndex = 5;
            this.stressDaysLabel.Text = "3";
            // 
            // interviewRadioButton
            // 
            this.interviewRadioButton.AutoSize = true;
            this.interviewRadioButton.Location = new System.Drawing.Point(23, 147);
            this.interviewRadioButton.Name = "interviewRadioButton";
            this.interviewRadioButton.Size = new System.Drawing.Size(105, 17);
            this.interviewRadioButton.TabIndex = 4;
            this.interviewRadioButton.TabStop = true;
            this.interviewRadioButton.Text = "How to Interview";
            this.interviewRadioButton.UseVisualStyleBackColor = true;
            // 
            // negotiationRadioButton
            // 
            this.negotiationRadioButton.AutoSize = true;
            this.negotiationRadioButton.Location = new System.Drawing.Point(23, 123);
            this.negotiationRadioButton.Name = "negotiationRadioButton";
            this.negotiationRadioButton.Size = new System.Drawing.Size(79, 17);
            this.negotiationRadioButton.TabIndex = 3;
            this.negotiationRadioButton.TabStop = true;
            this.negotiationRadioButton.Text = "Negotiation";
            this.negotiationRadioButton.UseVisualStyleBackColor = true;
            // 
            // supervisionRadioButton
            // 
            this.supervisionRadioButton.AutoSize = true;
            this.supervisionRadioButton.Location = new System.Drawing.Point(23, 99);
            this.supervisionRadioButton.Name = "supervisionRadioButton";
            this.supervisionRadioButton.Size = new System.Drawing.Size(107, 17);
            this.supervisionRadioButton.TabIndex = 2;
            this.supervisionRadioButton.TabStop = true;
            this.supervisionRadioButton.Text = "Supervision Skills";
            this.supervisionRadioButton.UseVisualStyleBackColor = true;
            // 
            // timeRadioButton
            // 
            this.timeRadioButton.AutoSize = true;
            this.timeRadioButton.Location = new System.Drawing.Point(23, 75);
            this.timeRadioButton.Name = "timeRadioButton";
            this.timeRadioButton.Size = new System.Drawing.Size(113, 17);
            this.timeRadioButton.TabIndex = 1;
            this.timeRadioButton.TabStop = true;
            this.timeRadioButton.Text = "Time Management";
            this.timeRadioButton.UseVisualStyleBackColor = true;
            // 
            // stressRadioButton
            // 
            this.stressRadioButton.AutoSize = true;
            this.stressRadioButton.Location = new System.Drawing.Point(23, 51);
            this.stressRadioButton.Name = "stressRadioButton";
            this.stressRadioButton.Size = new System.Drawing.Size(99, 17);
            this.stressRadioButton.TabIndex = 0;
            this.stressRadioButton.TabStop = true;
            this.stressRadioButton.Text = "Handling Stress";
            this.stressRadioButton.UseVisualStyleBackColor = true;
            // 
            // locationPanel
            // 
            this.locationPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.locationPanel.Controls.Add(this.raleighLodgingLabel);
            this.locationPanel.Controls.Add(this.phoenixLodgingLabel);
            this.locationPanel.Controls.Add(this.orlandoLodgingLabel);
            this.locationPanel.Controls.Add(this.dallasLodgingLabel);
            this.locationPanel.Controls.Add(this.chicagoLodgingLabel);
            this.locationPanel.Controls.Add(this.austinLodgingLabel);
            this.locationPanel.Controls.Add(this.costPerDayLabel);
            this.locationPanel.Controls.Add(this.locationLabel);
            this.locationPanel.Controls.Add(this.raleighRadioButton);
            this.locationPanel.Controls.Add(this.phoenixRadioButton);
            this.locationPanel.Controls.Add(this.orlandoRadioButton);
            this.locationPanel.Controls.Add(this.dallasRadioButton);
            this.locationPanel.Controls.Add(this.chicagoRadioButton);
            this.locationPanel.Controls.Add(this.austinRadioButton);
            this.locationPanel.Location = new System.Drawing.Point(439, 69);
            this.locationPanel.Name = "locationPanel";
            this.locationPanel.Size = new System.Drawing.Size(314, 224);
            this.locationPanel.TabIndex = 1;
            // 
            // austinLodgingLabel
            // 
            this.austinLodgingLabel.AutoSize = true;
            this.austinLodgingLabel.Location = new System.Drawing.Point(171, 51);
            this.austinLodgingLabel.Name = "austinLodgingLabel";
            this.austinLodgingLabel.Size = new System.Drawing.Size(31, 13);
            this.austinLodgingLabel.TabIndex = 8;
            this.austinLodgingLabel.Text = "$150";
            // 
            // costPerDayLabel
            // 
            this.costPerDayLabel.AutoSize = true;
            this.costPerDayLabel.Location = new System.Drawing.Point(115, 18);
            this.costPerDayLabel.Name = "costPerDayLabel";
            this.costPerDayLabel.Size = new System.Drawing.Size(111, 13);
            this.costPerDayLabel.TabIndex = 7;
            this.costPerDayLabel.Text = "Lodging Fees per Day";
            // 
            // locationLabel
            // 
            this.locationLabel.AutoSize = true;
            this.locationLabel.Location = new System.Drawing.Point(29, 18);
            this.locationLabel.Name = "locationLabel";
            this.locationLabel.Size = new System.Drawing.Size(48, 13);
            this.locationLabel.TabIndex = 6;
            this.locationLabel.Text = "Location";
            // 
            // raleighRadioButton
            // 
            this.raleighRadioButton.AutoSize = true;
            this.raleighRadioButton.Location = new System.Drawing.Point(29, 175);
            this.raleighRadioButton.Name = "raleighRadioButton";
            this.raleighRadioButton.Size = new System.Drawing.Size(61, 17);
            this.raleighRadioButton.TabIndex = 5;
            this.raleighRadioButton.TabStop = true;
            this.raleighRadioButton.Text = "Raleigh";
            this.raleighRadioButton.UseVisualStyleBackColor = true;
            // 
            // phoenixRadioButton
            // 
            this.phoenixRadioButton.AutoSize = true;
            this.phoenixRadioButton.Location = new System.Drawing.Point(29, 151);
            this.phoenixRadioButton.Name = "phoenixRadioButton";
            this.phoenixRadioButton.Size = new System.Drawing.Size(63, 17);
            this.phoenixRadioButton.TabIndex = 4;
            this.phoenixRadioButton.TabStop = true;
            this.phoenixRadioButton.Text = "Phoenix";
            this.phoenixRadioButton.UseVisualStyleBackColor = true;
            // 
            // orlandoRadioButton
            // 
            this.orlandoRadioButton.AutoSize = true;
            this.orlandoRadioButton.Location = new System.Drawing.Point(29, 127);
            this.orlandoRadioButton.Name = "orlandoRadioButton";
            this.orlandoRadioButton.Size = new System.Drawing.Size(62, 17);
            this.orlandoRadioButton.TabIndex = 3;
            this.orlandoRadioButton.TabStop = true;
            this.orlandoRadioButton.Text = "Orlando";
            this.orlandoRadioButton.UseVisualStyleBackColor = true;
            // 
            // dallasRadioButton
            // 
            this.dallasRadioButton.AutoSize = true;
            this.dallasRadioButton.Location = new System.Drawing.Point(29, 99);
            this.dallasRadioButton.Name = "dallasRadioButton";
            this.dallasRadioButton.Size = new System.Drawing.Size(54, 17);
            this.dallasRadioButton.TabIndex = 2;
            this.dallasRadioButton.TabStop = true;
            this.dallasRadioButton.Text = "Dallas";
            this.dallasRadioButton.UseVisualStyleBackColor = true;
            // 
            // chicagoRadioButton
            // 
            this.chicagoRadioButton.AutoSize = true;
            this.chicagoRadioButton.Location = new System.Drawing.Point(29, 77);
            this.chicagoRadioButton.Name = "chicagoRadioButton";
            this.chicagoRadioButton.Size = new System.Drawing.Size(64, 17);
            this.chicagoRadioButton.TabIndex = 1;
            this.chicagoRadioButton.TabStop = true;
            this.chicagoRadioButton.Text = "Chicago";
            this.chicagoRadioButton.UseVisualStyleBackColor = true;
            // 
            // austinRadioButton
            // 
            this.austinRadioButton.AutoSize = true;
            this.austinRadioButton.Location = new System.Drawing.Point(29, 51);
            this.austinRadioButton.Name = "austinRadioButton";
            this.austinRadioButton.Size = new System.Drawing.Size(54, 17);
            this.austinRadioButton.TabIndex = 0;
            this.austinRadioButton.TabStop = true;
            this.austinRadioButton.Text = "Austin";
            this.austinRadioButton.UseVisualStyleBackColor = true;
            // 
            // chicagoLodgingLabel
            // 
            this.chicagoLodgingLabel.AutoSize = true;
            this.chicagoLodgingLabel.Location = new System.Drawing.Point(171, 77);
            this.chicagoLodgingLabel.Name = "chicagoLodgingLabel";
            this.chicagoLodgingLabel.Size = new System.Drawing.Size(31, 13);
            this.chicagoLodgingLabel.TabIndex = 9;
            this.chicagoLodgingLabel.Text = "$225";
            // 
            // dallasLodgingLabel
            // 
            this.dallasLodgingLabel.AutoSize = true;
            this.dallasLodgingLabel.Location = new System.Drawing.Point(171, 99);
            this.dallasLodgingLabel.Name = "dallasLodgingLabel";
            this.dallasLodgingLabel.Size = new System.Drawing.Size(31, 13);
            this.dallasLodgingLabel.TabIndex = 10;
            this.dallasLodgingLabel.Text = "$175";
            // 
            // orlandoLodgingLabel
            // 
            this.orlandoLodgingLabel.AutoSize = true;
            this.orlandoLodgingLabel.Location = new System.Drawing.Point(171, 125);
            this.orlandoLodgingLabel.Name = "orlandoLodgingLabel";
            this.orlandoLodgingLabel.Size = new System.Drawing.Size(31, 13);
            this.orlandoLodgingLabel.TabIndex = 11;
            this.orlandoLodgingLabel.Text = "$300";
            // 
            // phoenixLodgingLabel
            // 
            this.phoenixLodgingLabel.AutoSize = true;
            this.phoenixLodgingLabel.Location = new System.Drawing.Point(171, 151);
            this.phoenixLodgingLabel.Name = "phoenixLodgingLabel";
            this.phoenixLodgingLabel.Size = new System.Drawing.Size(31, 13);
            this.phoenixLodgingLabel.TabIndex = 12;
            this.phoenixLodgingLabel.Text = "$175";
            // 
            // raleighLodgingLabel
            // 
            this.raleighLodgingLabel.AutoSize = true;
            this.raleighLodgingLabel.Location = new System.Drawing.Point(174, 175);
            this.raleighLodgingLabel.Name = "raleighLodgingLabel";
            this.raleighLodgingLabel.Size = new System.Drawing.Size(31, 13);
            this.raleighLodgingLabel.TabIndex = 13;
            this.raleighLodgingLabel.Text = "$150";
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(558, 439);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 2;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // calculateButton
            // 
            this.calculateButton.Location = new System.Drawing.Point(186, 438);
            this.calculateButton.Name = "calculateButton";
            this.calculateButton.Size = new System.Drawing.Size(75, 23);
            this.calculateButton.TabIndex = 3;
            this.calculateButton.Text = "Calculate Total";
            this.calculateButton.UseVisualStyleBackColor = true;
            this.calculateButton.Click += new System.EventHandler(this.calculateButton_Click);
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(397, 438);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(75, 23);
            this.clearButton.TabIndex = 4;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // totalCostLabel
            // 
            this.totalCostLabel.BackColor = System.Drawing.SystemColors.Info;
            this.totalCostLabel.Location = new System.Drawing.Point(317, 391);
            this.totalCostLabel.Name = "totalCostLabel";
            this.totalCostLabel.Size = new System.Drawing.Size(216, 23);
            this.totalCostLabel.TabIndex = 5;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(317, 363);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(165, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "Cost of registration and lodging is:";
            // 
            // workshopForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(896, 523);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.totalCostLabel);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.calculateButton);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.locationPanel);
            this.Controls.Add(this.workshopChoicePanel);
            this.Name = "workshopForm";
            this.Text = "Workshop Selector";
            this.workshopChoicePanel.ResumeLayout(false);
            this.workshopChoicePanel.PerformLayout();
            this.locationPanel.ResumeLayout(false);
            this.locationPanel.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel workshopChoicePanel;
        private System.Windows.Forms.Label interviewCostLabel;
        private System.Windows.Forms.Label negotiationCostLabel;
        private System.Windows.Forms.Label supervisionCostLabel;
        private System.Windows.Forms.Label timeCostLabel;
        private System.Windows.Forms.Label stressCostLabel;
        private System.Windows.Forms.Label interviewDaysLabel;
        private System.Windows.Forms.Label negotiationDaysLabel;
        private System.Windows.Forms.Label supervisionDaysLabel;
        private System.Windows.Forms.Label timeDaysLabel;
        private System.Windows.Forms.Label workshopCostLabel;
        private System.Windows.Forms.Label workshopDaysLlabel;
        private System.Windows.Forms.Label workshopNameLabel;
        private System.Windows.Forms.Label stressDaysLabel;
        private System.Windows.Forms.RadioButton interviewRadioButton;
        private System.Windows.Forms.RadioButton negotiationRadioButton;
        private System.Windows.Forms.RadioButton supervisionRadioButton;
        private System.Windows.Forms.RadioButton timeRadioButton;
        private System.Windows.Forms.RadioButton stressRadioButton;
        private System.Windows.Forms.Panel locationPanel;
        private System.Windows.Forms.Label austinLodgingLabel;
        private System.Windows.Forms.Label costPerDayLabel;
        private System.Windows.Forms.Label locationLabel;
        private System.Windows.Forms.RadioButton raleighRadioButton;
        private System.Windows.Forms.RadioButton phoenixRadioButton;
        private System.Windows.Forms.RadioButton orlandoRadioButton;
        private System.Windows.Forms.RadioButton dallasRadioButton;
        private System.Windows.Forms.RadioButton chicagoRadioButton;
        private System.Windows.Forms.RadioButton austinRadioButton;
        private System.Windows.Forms.Label raleighLodgingLabel;
        private System.Windows.Forms.Label phoenixLodgingLabel;
        private System.Windows.Forms.Label orlandoLodgingLabel;
        private System.Windows.Forms.Label dallasLodgingLabel;
        private System.Windows.Forms.Label chicagoLodgingLabel;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Button calculateButton;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Label totalCostLabel;
        private System.Windows.Forms.Label label1;
    }
}

