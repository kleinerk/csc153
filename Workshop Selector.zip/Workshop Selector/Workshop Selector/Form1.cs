﻿/*
* 27 Feb 2018
* CSC 153
* For my use
* using radio buttons
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Workshop_Selector
{
    public partial class workshopForm : Form
    {
        public workshopForm()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //  exit application
            this.Close();
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            // clear total cost label
            totalCostLabel.Text = "";
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            // initialize totalCost
            double totalCost = 0;
            int lodgingDays = 0;

            //  determine registration cost and number of lodging days
            if (stressRadioButton.Checked)
            {
                totalCost += 1000;
                lodgingDays = 3;
            }
            if (timeRadioButton.Checked)
            {
                totalCost += 800;
                lodgingDays = 3;
            }
            if (supervisionRadioButton.Checked)
            {
                totalCost += 1500;
                lodgingDays = 3;
            }
            if (negotiationRadioButton.Checked)
            {
                totalCost += 1300;
                lodgingDays = 5;
            }
            if (interviewRadioButton.Checked)
            {
                totalCost += 500;
                lodgingDays = 1;
            }

            //  add lodging cost to registration cost
            if (austinRadioButton.Checked)
            {
                totalCost += lodgingDays * 150;
            }
            if (chicagoRadioButton.Checked)
            {
                totalCost += lodgingDays * 225;
            }
            if (dallasRadioButton.Checked)
            {
                totalCost += lodgingDays * 175;
            }
            if (orlandoRadioButton.Checked)
            {
                totalCost += lodgingDays * 300;
            }
            if (phoenixRadioButton.Checked)
            {
                totalCost += lodgingDays * 175;
            }
            if (raleighRadioButton.Checked)
            {
                totalCost += lodgingDays * 150;
            }

            //  display total cost
            totalCostLabel.Text = totalCost.ToString("c");
        }
    }
}
