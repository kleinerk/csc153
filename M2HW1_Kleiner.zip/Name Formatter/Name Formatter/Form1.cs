﻿/**
* 6 Feb 2018
* CSC 153
* Kenneth Kleiner
* Program to learn string manipulation.  Made changes to use radio buttons and list box instead of buttons
*/



using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Name_Formatter
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void displayNameButton_Click(object sender, EventArgs e)
        {
            string titleToUse = titleListBox.SelectedItem.ToString() + " ";
            string middleToUse;
            if (middleNameTextBox.Text != "")
            {
                middleToUse = " " + middleNameTextBox.Text;
            }
            else
            {
                middleToUse = "";
            }
            if (tfmlRadioButton.Checked)
            {
                displayNameLabel.Text = titleToUse + firstNameTextBox.Text + middleToUse + " " + lastNameTextBox.Text;
            }
            else if (fmlRadioButton.Checked)
            {
                displayNameLabel.Text = firstNameTextBox.Text + middleToUse + " " + lastNameTextBox.Text;
            }
            else if (flRadioButton.Checked)
            {
                displayNameLabel.Text = firstNameTextBox.Text + " " + lastNameTextBox.Text;
            }
            else if (lfmtRadioButton.Checked)
            {
                displayNameLabel.Text = lastNameTextBox.Text + ", " + firstNameTextBox.Text + middleToUse + ", " + titleToUse;
            }
            else if (lfmRadioButton.Checked)
            {
                displayNameLabel.Text = lastNameTextBox.Text + ", " + firstNameTextBox.Text + middleToUse;
            }
            else
            {
                displayNameLabel.Text = lastNameTextBox.Text + ", " + firstNameTextBox.Text;
            }

        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
