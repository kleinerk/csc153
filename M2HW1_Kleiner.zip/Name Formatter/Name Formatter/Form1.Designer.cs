﻿namespace Name_Formatter
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.displayOrderGroupBox = new System.Windows.Forms.GroupBox();
            this.firstNameLabel = new System.Windows.Forms.Label();
            this.middleNameLabel = new System.Windows.Forms.Label();
            this.lastNameLabel = new System.Windows.Forms.Label();
            this.PreferredTitleLabel = new System.Windows.Forms.Label();
            this.titleListBox = new System.Windows.Forms.ListBox();
            this.firstNameTextBox = new System.Windows.Forms.TextBox();
            this.middleNameTextBox = new System.Windows.Forms.TextBox();
            this.lastNameTextBox = new System.Windows.Forms.TextBox();
            this.displayNameLabel = new System.Windows.Forms.Label();
            this.tfmlRadioButton = new System.Windows.Forms.RadioButton();
            this.fmlRadioButton = new System.Windows.Forms.RadioButton();
            this.flRadioButton = new System.Windows.Forms.RadioButton();
            this.lfmtRadioButton = new System.Windows.Forms.RadioButton();
            this.lfmRadioButton = new System.Windows.Forms.RadioButton();
            this.lfRadioButton = new System.Windows.Forms.RadioButton();
            this.displayNameButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.displayOrderGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // displayOrderGroupBox
            // 
            this.displayOrderGroupBox.Controls.Add(this.lfRadioButton);
            this.displayOrderGroupBox.Controls.Add(this.lfmRadioButton);
            this.displayOrderGroupBox.Controls.Add(this.lfmtRadioButton);
            this.displayOrderGroupBox.Controls.Add(this.flRadioButton);
            this.displayOrderGroupBox.Controls.Add(this.fmlRadioButton);
            this.displayOrderGroupBox.Controls.Add(this.tfmlRadioButton);
            this.displayOrderGroupBox.Location = new System.Drawing.Point(339, 34);
            this.displayOrderGroupBox.Name = "displayOrderGroupBox";
            this.displayOrderGroupBox.Size = new System.Drawing.Size(337, 100);
            this.displayOrderGroupBox.TabIndex = 0;
            this.displayOrderGroupBox.TabStop = false;
            this.displayOrderGroupBox.Text = "Display Options";
            // 
            // firstNameLabel
            // 
            this.firstNameLabel.AutoSize = true;
            this.firstNameLabel.Location = new System.Drawing.Point(50, 41);
            this.firstNameLabel.Name = "firstNameLabel";
            this.firstNameLabel.Size = new System.Drawing.Size(88, 13);
            this.firstNameLabel.TabIndex = 1;
            this.firstNameLabel.Text = "Enter First Name:";
            // 
            // middleNameLabel
            // 
            this.middleNameLabel.AutoSize = true;
            this.middleNameLabel.Location = new System.Drawing.Point(50, 72);
            this.middleNameLabel.Name = "middleNameLabel";
            this.middleNameLabel.Size = new System.Drawing.Size(100, 13);
            this.middleNameLabel.TabIndex = 2;
            this.middleNameLabel.Text = "Enter Middle Name:";
            // 
            // lastNameLabel
            // 
            this.lastNameLabel.AutoSize = true;
            this.lastNameLabel.Location = new System.Drawing.Point(50, 107);
            this.lastNameLabel.Name = "lastNameLabel";
            this.lastNameLabel.Size = new System.Drawing.Size(89, 13);
            this.lastNameLabel.TabIndex = 3;
            this.lastNameLabel.Text = "Enter Last Name:";
            // 
            // PreferredTitleLabel
            // 
            this.PreferredTitleLabel.AutoSize = true;
            this.PreferredTitleLabel.Location = new System.Drawing.Point(50, 144);
            this.PreferredTitleLabel.Name = "PreferredTitleLabel";
            this.PreferredTitleLabel.Size = new System.Drawing.Size(76, 13);
            this.PreferredTitleLabel.TabIndex = 4;
            this.PreferredTitleLabel.Text = "Preferred Title:";
            // 
            // titleListBox
            // 
            this.titleListBox.FormattingEnabled = true;
            this.titleListBox.Items.AddRange(new object[] {
            "Mr.",
            "Mrs.",
            "Ms.",
            "Dr.",
            "Prof.",
            "Gen.",
            "Sen."});
            this.titleListBox.Location = new System.Drawing.Point(179, 144);
            this.titleListBox.Name = "titleListBox";
            this.titleListBox.Size = new System.Drawing.Size(120, 95);
            this.titleListBox.TabIndex = 5;
            // 
            // firstNameTextBox
            // 
            this.firstNameTextBox.Location = new System.Drawing.Point(179, 34);
            this.firstNameTextBox.Name = "firstNameTextBox";
            this.firstNameTextBox.Size = new System.Drawing.Size(100, 20);
            this.firstNameTextBox.TabIndex = 6;
            // 
            // middleNameTextBox
            // 
            this.middleNameTextBox.Location = new System.Drawing.Point(179, 65);
            this.middleNameTextBox.Name = "middleNameTextBox";
            this.middleNameTextBox.Size = new System.Drawing.Size(100, 20);
            this.middleNameTextBox.TabIndex = 7;
            // 
            // lastNameTextBox
            // 
            this.lastNameTextBox.Location = new System.Drawing.Point(179, 99);
            this.lastNameTextBox.Name = "lastNameTextBox";
            this.lastNameTextBox.Size = new System.Drawing.Size(100, 20);
            this.lastNameTextBox.TabIndex = 8;
            // 
            // displayNameLabel
            // 
            this.displayNameLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.displayNameLabel.Location = new System.Drawing.Point(339, 216);
            this.displayNameLabel.Name = "displayNameLabel";
            this.displayNameLabel.Size = new System.Drawing.Size(337, 23);
            this.displayNameLabel.TabIndex = 9;
            this.displayNameLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tfmlRadioButton
            // 
            this.tfmlRadioButton.AutoSize = true;
            this.tfmlRadioButton.Location = new System.Drawing.Point(7, 20);
            this.tfmlRadioButton.Name = "tfmlRadioButton";
            this.tfmlRadioButton.Size = new System.Drawing.Size(124, 17);
            this.tfmlRadioButton.TabIndex = 0;
            this.tfmlRadioButton.TabStop = true;
            this.tfmlRadioButton.Text = "Title First Middle Last";
            this.tfmlRadioButton.UseVisualStyleBackColor = true;
            // 
            // fmlRadioButton
            // 
            this.fmlRadioButton.AutoSize = true;
            this.fmlRadioButton.Location = new System.Drawing.Point(7, 43);
            this.fmlRadioButton.Name = "fmlRadioButton";
            this.fmlRadioButton.Size = new System.Drawing.Size(101, 17);
            this.fmlRadioButton.TabIndex = 1;
            this.fmlRadioButton.TabStop = true;
            this.fmlRadioButton.Text = "First Middle Last";
            this.fmlRadioButton.UseVisualStyleBackColor = true;
            // 
            // flRadioButton
            // 
            this.flRadioButton.AutoSize = true;
            this.flRadioButton.Location = new System.Drawing.Point(7, 65);
            this.flRadioButton.Name = "flRadioButton";
            this.flRadioButton.Size = new System.Drawing.Size(67, 17);
            this.flRadioButton.TabIndex = 2;
            this.flRadioButton.TabStop = true;
            this.flRadioButton.Text = "First Last";
            this.flRadioButton.UseVisualStyleBackColor = true;
            // 
            // lfmtRadioButton
            // 
            this.lfmtRadioButton.AutoSize = true;
            this.lfmtRadioButton.Location = new System.Drawing.Point(160, 20);
            this.lfmtRadioButton.Name = "lfmtRadioButton";
            this.lfmtRadioButton.Size = new System.Drawing.Size(130, 17);
            this.lfmtRadioButton.TabIndex = 3;
            this.lfmtRadioButton.Text = "Last, First Middle, Title";
            this.lfmtRadioButton.UseVisualStyleBackColor = true;
            // 
            // lfmRadioButton
            // 
            this.lfmRadioButton.AutoSize = true;
            this.lfmRadioButton.Location = new System.Drawing.Point(160, 44);
            this.lfmRadioButton.Name = "lfmRadioButton";
            this.lfmRadioButton.Size = new System.Drawing.Size(104, 17);
            this.lfmRadioButton.TabIndex = 4;
            this.lfmRadioButton.TabStop = true;
            this.lfmRadioButton.Text = "Last, First Middle";
            this.lfmRadioButton.UseVisualStyleBackColor = true;
            // 
            // lfRadioButton
            // 
            this.lfRadioButton.AutoSize = true;
            this.lfRadioButton.Checked = true;
            this.lfRadioButton.Location = new System.Drawing.Point(160, 65);
            this.lfRadioButton.Name = "lfRadioButton";
            this.lfRadioButton.Size = new System.Drawing.Size(70, 17);
            this.lfRadioButton.TabIndex = 5;
            this.lfRadioButton.TabStop = true;
            this.lfRadioButton.Text = "Last, First";
            this.lfRadioButton.UseVisualStyleBackColor = true;
            // 
            // displayNameButton
            // 
            this.displayNameButton.Location = new System.Drawing.Point(182, 279);
            this.displayNameButton.Name = "displayNameButton";
            this.displayNameButton.Size = new System.Drawing.Size(117, 23);
            this.displayNameButton.TabIndex = 10;
            this.displayNameButton.Text = "Display Name";
            this.displayNameButton.UseVisualStyleBackColor = true;
            this.displayNameButton.Click += new System.EventHandler(this.displayNameButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(601, 279);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 11;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(781, 337);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.displayNameButton);
            this.Controls.Add(this.displayNameLabel);
            this.Controls.Add(this.lastNameTextBox);
            this.Controls.Add(this.middleNameTextBox);
            this.Controls.Add(this.firstNameTextBox);
            this.Controls.Add(this.titleListBox);
            this.Controls.Add(this.PreferredTitleLabel);
            this.Controls.Add(this.lastNameLabel);
            this.Controls.Add(this.middleNameLabel);
            this.Controls.Add(this.firstNameLabel);
            this.Controls.Add(this.displayOrderGroupBox);
            this.Name = "Form1";
            this.Text = "Name Formatter";
            this.displayOrderGroupBox.ResumeLayout(false);
            this.displayOrderGroupBox.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox displayOrderGroupBox;
        private System.Windows.Forms.RadioButton lfmtRadioButton;
        private System.Windows.Forms.RadioButton flRadioButton;
        private System.Windows.Forms.RadioButton fmlRadioButton;
        private System.Windows.Forms.RadioButton tfmlRadioButton;
        private System.Windows.Forms.Label firstNameLabel;
        private System.Windows.Forms.Label middleNameLabel;
        private System.Windows.Forms.Label lastNameLabel;
        private System.Windows.Forms.Label PreferredTitleLabel;
        private System.Windows.Forms.ListBox titleListBox;
        private System.Windows.Forms.TextBox firstNameTextBox;
        private System.Windows.Forms.TextBox middleNameTextBox;
        private System.Windows.Forms.TextBox lastNameTextBox;
        private System.Windows.Forms.Label displayNameLabel;
        private System.Windows.Forms.RadioButton lfRadioButton;
        private System.Windows.Forms.RadioButton lfmRadioButton;
        private System.Windows.Forms.Button displayNameButton;
        private System.Windows.Forms.Button exitButton;
    }
}

