﻿namespace RockPaper
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.startButton = new System.Windows.Forms.Button();
            this.playerOneChoiceLabel = new System.Windows.Forms.Label();
            this.playerTwoChoiceLabel = new System.Windows.Forms.Label();
            this.playerOneLabel = new System.Windows.Forms.Label();
            this.playerTwoLabel = new System.Windows.Forms.Label();
            this.resultLabel = new System.Windows.Forms.Label();
            this.exitButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // startButton
            // 
            this.startButton.Location = new System.Drawing.Point(104, 34);
            this.startButton.Name = "startButton";
            this.startButton.Size = new System.Drawing.Size(75, 23);
            this.startButton.TabIndex = 0;
            this.startButton.Text = "Start Game";
            this.startButton.UseVisualStyleBackColor = true;
            this.startButton.Click += new System.EventHandler(this.startButton_Click);
            // 
            // playerOneChoiceLabel
            // 
            this.playerOneChoiceLabel.BackColor = System.Drawing.SystemColors.Info;
            this.playerOneChoiceLabel.Location = new System.Drawing.Point(12, 110);
            this.playerOneChoiceLabel.Name = "playerOneChoiceLabel";
            this.playerOneChoiceLabel.Size = new System.Drawing.Size(100, 23);
            this.playerOneChoiceLabel.TabIndex = 1;
            // 
            // playerTwoChoiceLabel
            // 
            this.playerTwoChoiceLabel.BackColor = System.Drawing.SystemColors.Info;
            this.playerTwoChoiceLabel.Location = new System.Drawing.Point(172, 110);
            this.playerTwoChoiceLabel.Name = "playerTwoChoiceLabel";
            this.playerTwoChoiceLabel.Size = new System.Drawing.Size(100, 23);
            this.playerTwoChoiceLabel.TabIndex = 2;
            // 
            // playerOneLabel
            // 
            this.playerOneLabel.AutoSize = true;
            this.playerOneLabel.Location = new System.Drawing.Point(15, 77);
            this.playerOneLabel.Name = "playerOneLabel";
            this.playerOneLabel.Size = new System.Drawing.Size(81, 13);
            this.playerOneLabel.TabIndex = 3;
            this.playerOneLabel.Text = "Player 1 Choice";
            // 
            // playerTwoLabel
            // 
            this.playerTwoLabel.AutoSize = true;
            this.playerTwoLabel.Location = new System.Drawing.Point(175, 77);
            this.playerTwoLabel.Name = "playerTwoLabel";
            this.playerTwoLabel.Size = new System.Drawing.Size(81, 13);
            this.playerTwoLabel.TabIndex = 4;
            this.playerTwoLabel.Text = "Player 2 Choice";
            // 
            // resultLabel
            // 
            this.resultLabel.BackColor = System.Drawing.SystemColors.Info;
            this.resultLabel.Location = new System.Drawing.Point(15, 166);
            this.resultLabel.Name = "resultLabel";
            this.resultLabel.Size = new System.Drawing.Size(257, 23);
            this.resultLabel.TabIndex = 5;
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(104, 212);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 6;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 262);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.resultLabel);
            this.Controls.Add(this.playerTwoLabel);
            this.Controls.Add(this.playerOneLabel);
            this.Controls.Add(this.playerTwoChoiceLabel);
            this.Controls.Add(this.playerOneChoiceLabel);
            this.Controls.Add(this.startButton);
            this.Name = "Form1";
            this.Text = "Rock, Paper, Scissors";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button startButton;
        private System.Windows.Forms.Label playerOneChoiceLabel;
        private System.Windows.Forms.Label playerTwoChoiceLabel;
        private System.Windows.Forms.Label playerOneLabel;
        private System.Windows.Forms.Label playerTwoLabel;
        private System.Windows.Forms.Label resultLabel;
        private System.Windows.Forms.Button exitButton;
    }
}

