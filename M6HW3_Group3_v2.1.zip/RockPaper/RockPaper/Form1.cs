﻿/*
* 20 April 2018
* CSC 153
* Group - Kenneth Kleiner (code), Christopher Lee (pseudocode), Anthony O'Brien (flowchart)
* "Rock, Paper, Scissors" with "Lizard, Spock" added
* Uses nested switch statements for logic
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RockPaper
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void startButton_Click(object sender, EventArgs e)
        {
            int playerOneChoice;
            int playerTwoChoice;

            Random rand = new Random();
            playerOneChoice = rand.Next(5) + 1;
            playerTwoChoice = rand.Next(5) + 1;

            // 1 = rock
            // 2 = paper
            // 3 = scissors
            // 4 = lizard
            // 5 = Spock

            // playerOneChoiceLabel.Text = playerOneChoice.ToString();
            // playerTwoChoiceLabel.Text = playerTwoChoice.ToString();



            if (playerOneChoice == playerTwoChoice)
            {
                resultLabel.Text = "There is a tie";
                switch (playerOneChoice)
                {
                    case 1:
                        playerOneChoiceLabel.Text = "Rock";
                        playerTwoChoiceLabel.Text = "Rock";
                        break;
                    case 2:
                        playerOneChoiceLabel.Text = "Paper";
                        playerTwoChoiceLabel.Text = "Paper";
                        break;
                    case 3:
                        playerOneChoiceLabel.Text = "Scissors";
                        playerTwoChoiceLabel.Text = "Scissors";
                        break;
                    case 4:
                        playerOneChoiceLabel.Text = "Lizard";
                        playerTwoChoiceLabel.Text = "Lizard";
                        break;
                    case 5:
                        playerOneChoiceLabel.Text = "Spock";
                        playerTwoChoiceLabel.Text = "Spock";
                        break;
                }
            }
            else
            {
                switch (playerOneChoice)
                {
                    case 1:
                        playerOneChoiceLabel.Text = "Rock";
                        switch (playerTwoChoice)
                        {
                            case 3:
                                playerTwoChoiceLabel.Text = "Scissors";
                                resultLabel.Text = "Rock crushes Scissors";
                                break;
                            case 4:
                                playerTwoChoiceLabel.Text = "Lizard";
                                resultLabel.Text = "Rock crushes Lizard";
                                break;
                            case 2:
                                playerTwoChoiceLabel.Text = "Paper";
                                resultLabel.Text = "Paper covers Rock";
                                break;
                            case 5:
                                playerTwoChoiceLabel.Text = "Spock";
                                resultLabel.Text = "Spock vaporizes Rock";
                                break;
                        }
                        break;
                    case 2:
                        playerOneChoiceLabel.Text = "Paper";
                        switch (playerTwoChoice)
                        {
                            case 1:
                                playerTwoChoiceLabel.Text = "Rock";
                                resultLabel.Text = "Paper covers Rock";
                                break;
                            case 5:
                                playerTwoChoiceLabel.Text = "Spock";
                                resultLabel.Text = "Paper disproves Spock";
                                break;
                            case 3:
                                playerTwoChoiceLabel.Text = "Scissors";
                                resultLabel.Text = "Scissors cuts Paper";
                                break;
                            case 4:
                                playerTwoChoiceLabel.Text = "Lizard";
                                resultLabel.Text = "Lizard eats Paper";
                                break;
                        }
                        break;
                    case 3:
                        playerOneChoiceLabel.Text = "Scissors";
                        switch (playerTwoChoice)
                        {
                            case 2:
                                playerTwoChoiceLabel.Text = "Paper";
                                resultLabel.Text = "Scissors cuts Paper";
                                break;
                            case 4:
                                playerTwoChoiceLabel.Text = "Lizard";
                                resultLabel.Text = "Scissors decapitates Lizard";
                                break;
                            case 1:
                                playerTwoChoiceLabel.Text = "Rock";
                                resultLabel.Text = "Rock crushes Scissors";
                                break;
                            case 5:
                                playerTwoChoiceLabel.Text = "Spock";
                                resultLabel.Text = "Spock smashes Scissors";
                                break;
                        }
                        break;
                    case 4:
                        playerOneChoiceLabel.Text = "Lizard";
                        switch (playerTwoChoice)
                        {
                            case 2:
                                playerTwoChoiceLabel.Text = "Paper";
                                resultLabel.Text = "Lizard eats Paper";
                                break;
                            case 5:
                                playerTwoChoiceLabel.Text = "Spock";
                                resultLabel.Text = "Lizard poisons Spock";
                                break;
                            case 1:
                                playerTwoChoiceLabel.Text = "Rock";
                                resultLabel.Text = "Rock crushes Lizard";
                                break;
                            case 3:
                                playerTwoChoiceLabel.Text = "Scissors";
                                resultLabel.Text = "Scissors decapitates Lizard";
                                break;
                        }
                        break;
                    case 5:
                        playerOneChoiceLabel.Text = "Spock";
                        switch (playerTwoChoice)
                        {
                            case 1:
                                playerTwoChoiceLabel.Text = "Rock";
                                resultLabel.Text = "Spock vaporizes Rock";
                                break;
                            case 3:
                                playerTwoChoiceLabel.Text = "Scissors";
                                resultLabel.Text = "Spock smashes Scissors";
                                break;
                            case 2:
                                playerTwoChoiceLabel.Text = "Paper";
                                resultLabel.Text = "Paper disproves Spock";
                                break;
                            case 4:
                                playerTwoChoiceLabel.Text = "Lizard";
                                resultLabel.Text = "Lizard poisons Spock";
                                break;
                        }
                        break;
                }
            }
        }
    }
}
