﻿/**
* Date
* CSC 153
* Kenneth Kleiner
* Latin Translator for left, right, center
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Latin_Translator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void sinisterButton_Click(object sender, EventArgs e)
        {
            labelTranslation.Text = "left";
        }

        private void dexterButton_Click(object sender, EventArgs e)
        {
            labelTranslation.Text = "right";
        }

        private void mediumButton_Click(object sender, EventArgs e)
        {
            labelTranslation.Text = "center";
        }
    }
}
