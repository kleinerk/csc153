﻿/*
* 21 February 2018
* CSC 153
* Kenneth Kleiner
* This program can display the roman numeral equivalent from 1 to 10
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Roman_Numeral_Converter
{
    public partial class romanNumeralConverter : Form
    {
        public romanNumeralConverter()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Close application
            this.Close();
        }

        private void convertButton_Click(object sender, EventArgs e)
        {
            // Use input to decide conversion.
            switch (numberToConvertTextBox.Text)
            {
                case "1":
                    convertedNumberLabel.Text = "I";
                    break;
                case "2":
                    convertedNumberLabel.Text = "II";
                    break;
                case "3":
                    convertedNumberLabel.Text = "III";
                    break;
                case "4":
                    convertedNumberLabel.Text = "IV";
                    break;
                case "5":
                    convertedNumberLabel.Text = "V";
                    break;
                case "6":
                    convertedNumberLabel.Text = "VI";
                    break;
                case "7":
                    convertedNumberLabel.Text = "VII";
                    break;
                case "8":
                    convertedNumberLabel.Text = "VIII";
                    break;
                case "9":
                    convertedNumberLabel.Text = "IX";
                    break;
                case "10":
                    convertedNumberLabel.Text = "X";
                    break;
                default:  // If input value is not from 1 to 10, display error message
                    MessageBox.Show("Number entered is not between 1 and 10 inclusive");
                    numberToConvertTextBox.Text = "";   // Clear input box
                    convertedNumberLabel.Text = "";     // Clear converted number
                    numberToConvertTextBox.Focus();     // Send focus to input box
                    break;
            }
        }
    }
}
