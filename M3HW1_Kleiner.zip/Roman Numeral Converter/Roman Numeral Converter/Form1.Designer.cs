﻿namespace Roman_Numeral_Converter
{
    partial class romanNumeralConverter
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.numberToConvertTextBox = new System.Windows.Forms.TextBox();
            this.instructionLabel = new System.Windows.Forms.Label();
            this.convertedNumberLabel = new System.Windows.Forms.Label();
            this.resultLabel = new System.Windows.Forms.Label();
            this.convertButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // numberToConvertTextBox
            // 
            this.numberToConvertTextBox.Location = new System.Drawing.Point(89, 63);
            this.numberToConvertTextBox.Name = "numberToConvertTextBox";
            this.numberToConvertTextBox.Size = new System.Drawing.Size(100, 20);
            this.numberToConvertTextBox.TabIndex = 0;
            // 
            // instructionLabel
            // 
            this.instructionLabel.AutoSize = true;
            this.instructionLabel.Location = new System.Drawing.Point(74, 29);
            this.instructionLabel.Name = "instructionLabel";
            this.instructionLabel.Size = new System.Drawing.Size(138, 13);
            this.instructionLabel.TabIndex = 1;
            this.instructionLabel.Text = "Enter a number from 1 to 10";
            // 
            // convertedNumberLabel
            // 
            this.convertedNumberLabel.BackColor = System.Drawing.SystemColors.Info;
            this.convertedNumberLabel.Location = new System.Drawing.Point(89, 134);
            this.convertedNumberLabel.Name = "convertedNumberLabel";
            this.convertedNumberLabel.Size = new System.Drawing.Size(100, 23);
            this.convertedNumberLabel.TabIndex = 2;
            this.convertedNumberLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // resultLabel
            // 
            this.resultLabel.AutoSize = true;
            this.resultLabel.Location = new System.Drawing.Point(74, 109);
            this.resultLabel.Name = "resultLabel";
            this.resultLabel.Size = new System.Drawing.Size(123, 13);
            this.resultLabel.TabIndex = 3;
            this.resultLabel.Text = "Your number converts to";
            // 
            // convertButton
            // 
            this.convertButton.Location = new System.Drawing.Point(101, 172);
            this.convertButton.Name = "convertButton";
            this.convertButton.Size = new System.Drawing.Size(75, 23);
            this.convertButton.TabIndex = 4;
            this.convertButton.Text = "Convert";
            this.convertButton.UseVisualStyleBackColor = true;
            this.convertButton.Click += new System.EventHandler(this.convertButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(101, 213);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 5;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // romanNumeralConverter
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 262);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.convertButton);
            this.Controls.Add(this.resultLabel);
            this.Controls.Add(this.convertedNumberLabel);
            this.Controls.Add(this.instructionLabel);
            this.Controls.Add(this.numberToConvertTextBox);
            this.Name = "romanNumeralConverter";
            this.Text = "Roman Numeral Converter";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox numberToConvertTextBox;
        private System.Windows.Forms.Label instructionLabel;
        private System.Windows.Forms.Label convertedNumberLabel;
        private System.Windows.Forms.Label resultLabel;
        private System.Windows.Forms.Button convertButton;
        private System.Windows.Forms.Button exitButton;
    }
}

