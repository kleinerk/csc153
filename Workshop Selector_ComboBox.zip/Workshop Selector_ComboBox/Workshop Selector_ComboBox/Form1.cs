﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Workshop_Selector_ComboBox
{
    public partial class workshopComboForm : Form
    {
        public workshopComboForm()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //  exit application
            this.Close();
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            //  clear total cost label
            totalCostLabel.Text = "";
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            //  initialize variables
            double totalCost = 0;
            int lodgingDays = 0;

            string workshop;    // to hold chosen workshop
            string location;    // to hold chosen location

            if (workshopListBox.SelectedIndex != -1 && locationListBox.SelectedIndex != -1)
            {
                workshop = workshopListBox.SelectedItem.ToString();

                // determine workshop
                switch (workshop)
                {
                    case "Handling Stress	3 days	$1,000 fee":
                        totalCost += 1000;
                        lodgingDays = 3;
                        break;
                    case "Time Management	3 days	   $800 fee":
                        totalCost += 800;
                        lodgingDays = 3;
                        break;
                    case "Supervision Skills	3 days	$1,500 fee":
                        totalCost += 1500;
                        lodgingDays = 3;
                        break;
                    case "Negotiation	5 days	$1,300 fee":
                        totalCost += 1300;
                        lodgingDays = 5;
                        break;
                    case "How to Interview	1 day	   $500 fee":
                        totalCost += 500;
                        lodgingDays = 1;
                        break;
                }

                location = locationListBox.SelectedItem.ToString();
                switch (location)
                {
                    case "Austin	$150":
                        totalCost += lodgingDays * 150;
                        break;
                    case "Chicago	$225":
                        totalCost += lodgingDays * 225;
                        break;
                    case "Dallas	$175":
                        totalCost += lodgingDays * 175;
                        break;
                    case "Orlando	$300":
                        totalCost += lodgingDays * 300;
                        break;
                    case "Phoenix	$175":
                        totalCost += lodgingDays * 175;
                        break;
                    case "Raleigh	$150":
                        totalCost += lodgingDays * 150;
                        break;
                }

                totalCostLabel.Text = totalCost.ToString("c");
            }
            else
            {
                MessageBox.Show("Please choose a workshop and a location.");
            }
        }
    }
}
