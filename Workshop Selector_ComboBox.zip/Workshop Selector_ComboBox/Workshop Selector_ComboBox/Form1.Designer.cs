﻿namespace Workshop_Selector_ComboBox
{
    partial class workshopComboForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.workshopSelectorLabel = new System.Windows.Forms.Label();
            this.exitButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.totalCostLabel = new System.Windows.Forms.Label();
            this.locationListBox = new System.Windows.Forms.ListBox();
            this.workshopListBox = new System.Windows.Forms.ListBox();
            this.locationLabel = new System.Windows.Forms.Label();
            this.calculateButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // workshopSelectorLabel
            // 
            this.workshopSelectorLabel.AutoSize = true;
            this.workshopSelectorLabel.Location = new System.Drawing.Point(67, 37);
            this.workshopSelectorLabel.Name = "workshopSelectorLabel";
            this.workshopSelectorLabel.Size = new System.Drawing.Size(147, 13);
            this.workshopSelectorLabel.TabIndex = 1;
            this.workshopSelectorLabel.Text = "Workshop Name - days - cost";
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(359, 198);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 2;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(242, 198);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(75, 23);
            this.clearButton.TabIndex = 3;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // totalCostLabel
            // 
            this.totalCostLabel.BackColor = System.Drawing.SystemColors.Info;
            this.totalCostLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.totalCostLabel.Location = new System.Drawing.Point(67, 161);
            this.totalCostLabel.Name = "totalCostLabel";
            this.totalCostLabel.Size = new System.Drawing.Size(250, 23);
            this.totalCostLabel.TabIndex = 4;
            // 
            // locationListBox
            // 
            this.locationListBox.FormattingEnabled = true;
            this.locationListBox.Items.AddRange(new object[] {
            "Austin\t$150",
            "Chicago\t$225",
            "Dallas\t$175",
            "Orlando\t$300",
            "Phoenix\t$175",
            "Raleigh\t$150"});
            this.locationListBox.Location = new System.Drawing.Point(359, 69);
            this.locationListBox.Name = "locationListBox";
            this.locationListBox.Size = new System.Drawing.Size(120, 82);
            this.locationListBox.TabIndex = 5;
            // 
            // workshopListBox
            // 
            this.workshopListBox.FormattingEnabled = true;
            this.workshopListBox.Items.AddRange(new object[] {
            "Handling Stress\t3 days\t$1,000 fee",
            "Time Management\t3 days\t   $800 fee",
            "Supervision Skills\t3 days\t$1,500 fee",
            "Negotiation\t5 days\t$1,300 fee",
            "How to Interview\t1 day\t   $500 fee"});
            this.workshopListBox.Location = new System.Drawing.Point(70, 69);
            this.workshopListBox.Name = "workshopListBox";
            this.workshopListBox.Size = new System.Drawing.Size(222, 69);
            this.workshopListBox.TabIndex = 6;
            // 
            // locationLabel
            // 
            this.locationLabel.AutoSize = true;
            this.locationLabel.Location = new System.Drawing.Point(359, 37);
            this.locationLabel.Name = "locationLabel";
            this.locationLabel.Size = new System.Drawing.Size(116, 13);
            this.locationLabel.TabIndex = 7;
            this.locationLabel.Text = "Location - Cost per day";
            // 
            // calculateButton
            // 
            this.calculateButton.Location = new System.Drawing.Point(70, 197);
            this.calculateButton.Name = "calculateButton";
            this.calculateButton.Size = new System.Drawing.Size(75, 41);
            this.calculateButton.TabIndex = 8;
            this.calculateButton.Text = "Calculate Cost";
            this.calculateButton.UseVisualStyleBackColor = true;
            this.calculateButton.Click += new System.EventHandler(this.calculateButton_Click);
            // 
            // workshopComboForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(801, 324);
            this.Controls.Add(this.calculateButton);
            this.Controls.Add(this.locationLabel);
            this.Controls.Add(this.workshopListBox);
            this.Controls.Add(this.locationListBox);
            this.Controls.Add(this.totalCostLabel);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.workshopSelectorLabel);
            this.Name = "workshopComboForm";
            this.Text = "Workshop Selector Combo";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label workshopSelectorLabel;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Label totalCostLabel;
        private System.Windows.Forms.ListBox locationListBox;
        private System.Windows.Forms.ListBox workshopListBox;
        private System.Windows.Forms.Label locationLabel;
        private System.Windows.Forms.Button calculateButton;
    }
}

