﻿/*
* 27 March 2018
* CSC 153
* Kenneth Kleiner
* Processing text file in and out
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace M4_extra
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void processFileButton_Click(object sender, EventArgs e)
        {
            try
            {
                // variables for records
                string recordIn;
                string recordOut;

                // variables for name processing
                string fullName, lastName, firstInitial;

                int commaLocation;

                // variables for output
                string e_mail, userName;
                string spaceString = "       ";
                string domainExtension = "@student.faytechcc.edu";

                int spacesToAdd;
                int recordsProcessed = 0;

                // input file - required
                StreamReader inputFile;

                // get file to open
                if (openFile.ShowDialog() == DialogResult.OK)
                {
                    // open file
                    inputFile = File.OpenText(openFile.FileName);
                    // output file - required
                    StreamWriter outputFile;

                    // file save option
                    if (saveFile.ShowDialog() == DialogResult.OK)
                    {
                        outputFile = File.CreateText(saveFile.FileName);

                        // process input file
                        while (!inputFile.EndOfStream)
                        {
                            // read input record
                            recordIn = inputFile.ReadLine();
                            
                            // get full name                            
                            fullName = recordIn.Substring(13, 20);
                            
                            // find comma
                            commaLocation = fullName.IndexOf(',', 0);
                            
                            // depending on comma location, get last name
                            if (commaLocation <= 7)
                            {
                                lastName = fullName.Substring(0, commaLocation).ToLower();
                                spacesToAdd = 10 - commaLocation;
                            }
                            else
                            {
                                lastName = fullName.Substring(0, 7).ToLower();
                                spacesToAdd = 3;
                            }

                            // get first initial based on comma location
                            firstInitial = fullName.Substring(commaLocation + 2, 1).ToLower();  // + 2 accounts for comma and space

                            // update username for e-mail
                            userName = lastName + firstInitial + recordIn.Substring(9, 4);
                            e_mail = userName + domainExtension;

                            // update username for writing to file
                            userName = userName + spaceString.Substring(0, spacesToAdd);

                            // write output record
                            recordOut = fullName + userName + e_mail;
                            outputFile.WriteLine(recordOut);

                            recordsProcessed++;
                        }

                        // close input and output files
                        inputFile.Close();
                        outputFile.Close();
                        MessageBox.Show("Records Processed: " + recordsProcessed.ToString());
                    }
                    else
                    {
                        MessageBox.Show("Open operation canceled.");
                    }
                }
                else
                {
                    MessageBox.Show("Save operation canceled.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
