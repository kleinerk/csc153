﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _9_4_Employee
{
    class Employee
    {
        private string _name;
        private int _IDnumber;
        private string _dept;
        private string _position;

        public Employee(string name, int IDnumber, string dept, string position)
        {
            _name = name;
            _IDnumber = IDnumber;
            _dept = dept;
            _position = position;
        }
        public Employee(string name, int IDnumber)
        {
            _name = name;
            _IDnumber = IDnumber;
            _dept = "";
            _position = "";
        }

        public Employee()
        {
            _name = "";
            _IDnumber = 0;
            _dept = "";
            _position = "";
        }

        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }
        public int IDnumber
        {
            get { return _IDnumber; }
            set { _IDnumber = value; }
        }
        public string Department
        {
            get { return _dept; }
            set { _dept = value; }
        }
        public string Position
        {
            get { return _position; }
            set { _position = value; }
        }
    }
}
