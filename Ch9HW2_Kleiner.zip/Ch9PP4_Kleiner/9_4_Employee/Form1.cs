﻿/*
* 3 May 2018
* CSC 153
* Kenneth Kleiner
* More instantiation but creating overloaded methods
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _9_4_Employee
{
    public partial class Form1 : Form
    {
        private Employee emp1 = new Employee("Susan Myers", 47899, "Accounting", "Vice President");
        private Employee emp2 = new Employee("Mark Jones", 39119, "IT", "Programmer");
        private Employee emp3 = new Employee("Joy Rogers", 81774, "Manufacturing", "Engineer");

        public Form1()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void emp1_Button_Click(object sender, EventArgs e)
        {
            nameDisplayLabel.Text = emp1.Name;
            idNumberDisplayLabel.Text = emp1.IDnumber.ToString();
            deptDisplayLabel.Text = emp1.Department;
            positionDisplayLabel.Text = emp1.Position;
        }

        private void emp2_Button_Click(object sender, EventArgs e)
        {
            nameDisplayLabel.Text = emp2.Name;
            idNumberDisplayLabel.Text = emp2.IDnumber.ToString();
            deptDisplayLabel.Text = emp2.Department;
            positionDisplayLabel.Text = emp2.Position;
        }

        private void emp3_Button_Click(object sender, EventArgs e)
        {
            nameDisplayLabel.Text = emp3.Name;
            idNumberDisplayLabel.Text = emp3.IDnumber.ToString();
            deptDisplayLabel.Text = emp3.Department;
            positionDisplayLabel.Text = emp3.Position;
        }
    }
}
