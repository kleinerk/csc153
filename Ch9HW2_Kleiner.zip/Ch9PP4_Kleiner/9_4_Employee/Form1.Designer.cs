﻿namespace _9_4_Employee
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.nameLabel = new System.Windows.Forms.Label();
            this.idNumberLabel = new System.Windows.Forms.Label();
            this.deptLabel = new System.Windows.Forms.Label();
            this.positionLabel = new System.Windows.Forms.Label();
            this.nameDisplayLabel = new System.Windows.Forms.Label();
            this.idNumberDisplayLabel = new System.Windows.Forms.Label();
            this.deptDisplayLabel = new System.Windows.Forms.Label();
            this.positionDisplayLabel = new System.Windows.Forms.Label();
            this.emp1_Button = new System.Windows.Forms.Button();
            this.emp2_Button = new System.Windows.Forms.Button();
            this.emp3_Button = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // nameLabel
            // 
            this.nameLabel.AutoSize = true;
            this.nameLabel.Location = new System.Drawing.Point(13, 45);
            this.nameLabel.Name = "nameLabel";
            this.nameLabel.Size = new System.Drawing.Size(35, 13);
            this.nameLabel.TabIndex = 0;
            this.nameLabel.Text = "Name";
            // 
            // idNumberLabel
            // 
            this.idNumberLabel.AutoSize = true;
            this.idNumberLabel.Location = new System.Drawing.Point(13, 80);
            this.idNumberLabel.Name = "idNumberLabel";
            this.idNumberLabel.Size = new System.Drawing.Size(58, 13);
            this.idNumberLabel.TabIndex = 1;
            this.idNumberLabel.Text = "ID Number";
            // 
            // deptLabel
            // 
            this.deptLabel.AutoSize = true;
            this.deptLabel.Location = new System.Drawing.Point(13, 110);
            this.deptLabel.Name = "deptLabel";
            this.deptLabel.Size = new System.Drawing.Size(62, 13);
            this.deptLabel.TabIndex = 2;
            this.deptLabel.Text = "Department";
            // 
            // positionLabel
            // 
            this.positionLabel.AutoSize = true;
            this.positionLabel.Location = new System.Drawing.Point(13, 142);
            this.positionLabel.Name = "positionLabel";
            this.positionLabel.Size = new System.Drawing.Size(44, 13);
            this.positionLabel.TabIndex = 3;
            this.positionLabel.Text = "Position";
            // 
            // nameDisplayLabel
            // 
            this.nameDisplayLabel.BackColor = System.Drawing.SystemColors.Info;
            this.nameDisplayLabel.Location = new System.Drawing.Point(119, 44);
            this.nameDisplayLabel.Name = "nameDisplayLabel";
            this.nameDisplayLabel.Size = new System.Drawing.Size(100, 23);
            this.nameDisplayLabel.TabIndex = 4;
            // 
            // idNumberDisplayLabel
            // 
            this.idNumberDisplayLabel.BackColor = System.Drawing.SystemColors.Info;
            this.idNumberDisplayLabel.Location = new System.Drawing.Point(119, 80);
            this.idNumberDisplayLabel.Name = "idNumberDisplayLabel";
            this.idNumberDisplayLabel.Size = new System.Drawing.Size(100, 23);
            this.idNumberDisplayLabel.TabIndex = 5;
            // 
            // deptDisplayLabel
            // 
            this.deptDisplayLabel.BackColor = System.Drawing.SystemColors.Info;
            this.deptDisplayLabel.Location = new System.Drawing.Point(119, 110);
            this.deptDisplayLabel.Name = "deptDisplayLabel";
            this.deptDisplayLabel.Size = new System.Drawing.Size(100, 23);
            this.deptDisplayLabel.TabIndex = 6;
            // 
            // positionDisplayLabel
            // 
            this.positionDisplayLabel.BackColor = System.Drawing.SystemColors.Info;
            this.positionDisplayLabel.Location = new System.Drawing.Point(119, 142);
            this.positionDisplayLabel.Name = "positionDisplayLabel";
            this.positionDisplayLabel.Size = new System.Drawing.Size(100, 23);
            this.positionDisplayLabel.TabIndex = 7;
            // 
            // emp1_Button
            // 
            this.emp1_Button.Location = new System.Drawing.Point(13, 191);
            this.emp1_Button.Name = "emp1_Button";
            this.emp1_Button.Size = new System.Drawing.Size(75, 23);
            this.emp1_Button.TabIndex = 8;
            this.emp1_Button.Text = "Employee 1";
            this.emp1_Button.UseVisualStyleBackColor = true;
            this.emp1_Button.Click += new System.EventHandler(this.emp1_Button_Click);
            // 
            // emp2_Button
            // 
            this.emp2_Button.Location = new System.Drawing.Point(94, 191);
            this.emp2_Button.Name = "emp2_Button";
            this.emp2_Button.Size = new System.Drawing.Size(75, 23);
            this.emp2_Button.TabIndex = 9;
            this.emp2_Button.Text = "Employee 2";
            this.emp2_Button.UseVisualStyleBackColor = true;
            this.emp2_Button.Click += new System.EventHandler(this.emp2_Button_Click);
            // 
            // emp3_Button
            // 
            this.emp3_Button.Location = new System.Drawing.Point(175, 191);
            this.emp3_Button.Name = "emp3_Button";
            this.emp3_Button.Size = new System.Drawing.Size(75, 23);
            this.emp3_Button.TabIndex = 10;
            this.emp3_Button.Text = "Employee 3";
            this.emp3_Button.UseVisualStyleBackColor = true;
            this.emp3_Button.Click += new System.EventHandler(this.emp3_Button_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(94, 246);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 12;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 309);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.emp3_Button);
            this.Controls.Add(this.emp2_Button);
            this.Controls.Add(this.emp1_Button);
            this.Controls.Add(this.positionDisplayLabel);
            this.Controls.Add(this.deptDisplayLabel);
            this.Controls.Add(this.idNumberDisplayLabel);
            this.Controls.Add(this.nameDisplayLabel);
            this.Controls.Add(this.positionLabel);
            this.Controls.Add(this.deptLabel);
            this.Controls.Add(this.idNumberLabel);
            this.Controls.Add(this.nameLabel);
            this.Name = "Form1";
            this.Text = "Employee Information";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label nameLabel;
        private System.Windows.Forms.Label idNumberLabel;
        private System.Windows.Forms.Label deptLabel;
        private System.Windows.Forms.Label positionLabel;
        private System.Windows.Forms.Label nameDisplayLabel;
        private System.Windows.Forms.Label idNumberDisplayLabel;
        private System.Windows.Forms.Label deptDisplayLabel;
        private System.Windows.Forms.Label positionDisplayLabel;
        private System.Windows.Forms.Button emp1_Button;
        private System.Windows.Forms.Button emp2_Button;
        private System.Windows.Forms.Button emp3_Button;
        private System.Windows.Forms.Button exitButton;
    }
}

