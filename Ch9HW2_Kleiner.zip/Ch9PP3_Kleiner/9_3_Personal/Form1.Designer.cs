﻿namespace _9_3_Personal
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.nameLabel = new System.Windows.Forms.Label();
            this.addressLabel = new System.Windows.Forms.Label();
            this.ageLabel = new System.Windows.Forms.Label();
            this.phoneLabel = new System.Windows.Forms.Label();
            this.nameDisplayLabel = new System.Windows.Forms.Label();
            this.addressDisplayLabel = new System.Windows.Forms.Label();
            this.ageDisplayLabel = new System.Windows.Forms.Label();
            this.phoneDisplayLabel = new System.Windows.Forms.Label();
            this.person1_Button = new System.Windows.Forms.Button();
            this.person2_Button = new System.Windows.Forms.Button();
            this.person3_Button = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // nameLabel
            // 
            this.nameLabel.AutoSize = true;
            this.nameLabel.Location = new System.Drawing.Point(13, 37);
            this.nameLabel.Name = "nameLabel";
            this.nameLabel.Size = new System.Drawing.Size(35, 13);
            this.nameLabel.TabIndex = 0;
            this.nameLabel.Text = "Name";
            // 
            // addressLabel
            // 
            this.addressLabel.AutoSize = true;
            this.addressLabel.Location = new System.Drawing.Point(13, 64);
            this.addressLabel.Name = "addressLabel";
            this.addressLabel.Size = new System.Drawing.Size(45, 13);
            this.addressLabel.TabIndex = 1;
            this.addressLabel.Text = "Address";
            // 
            // ageLabel
            // 
            this.ageLabel.AutoSize = true;
            this.ageLabel.Location = new System.Drawing.Point(16, 92);
            this.ageLabel.Name = "ageLabel";
            this.ageLabel.Size = new System.Drawing.Size(26, 13);
            this.ageLabel.TabIndex = 2;
            this.ageLabel.Text = "Age";
            // 
            // phoneLabel
            // 
            this.phoneLabel.AutoSize = true;
            this.phoneLabel.Location = new System.Drawing.Point(16, 122);
            this.phoneLabel.Name = "phoneLabel";
            this.phoneLabel.Size = new System.Drawing.Size(48, 13);
            this.phoneLabel.TabIndex = 3;
            this.phoneLabel.Text = "Phone #";
            // 
            // nameDisplayLabel
            // 
            this.nameDisplayLabel.BackColor = System.Drawing.SystemColors.Info;
            this.nameDisplayLabel.Location = new System.Drawing.Point(118, 36);
            this.nameDisplayLabel.Name = "nameDisplayLabel";
            this.nameDisplayLabel.Size = new System.Drawing.Size(100, 23);
            this.nameDisplayLabel.TabIndex = 4;
            // 
            // addressDisplayLabel
            // 
            this.addressDisplayLabel.BackColor = System.Drawing.SystemColors.Info;
            this.addressDisplayLabel.Location = new System.Drawing.Point(118, 64);
            this.addressDisplayLabel.Name = "addressDisplayLabel";
            this.addressDisplayLabel.Size = new System.Drawing.Size(100, 23);
            this.addressDisplayLabel.TabIndex = 5;
            // 
            // ageDisplayLabel
            // 
            this.ageDisplayLabel.BackColor = System.Drawing.SystemColors.Info;
            this.ageDisplayLabel.Location = new System.Drawing.Point(118, 92);
            this.ageDisplayLabel.Name = "ageDisplayLabel";
            this.ageDisplayLabel.Size = new System.Drawing.Size(100, 23);
            this.ageDisplayLabel.TabIndex = 6;
            // 
            // phoneDisplayLabel
            // 
            this.phoneDisplayLabel.BackColor = System.Drawing.SystemColors.Info;
            this.phoneDisplayLabel.Location = new System.Drawing.Point(118, 122);
            this.phoneDisplayLabel.Name = "phoneDisplayLabel";
            this.phoneDisplayLabel.Size = new System.Drawing.Size(100, 23);
            this.phoneDisplayLabel.TabIndex = 7;
            // 
            // person1_Button
            // 
            this.person1_Button.Location = new System.Drawing.Point(19, 188);
            this.person1_Button.Name = "person1_Button";
            this.person1_Button.Size = new System.Drawing.Size(75, 23);
            this.person1_Button.TabIndex = 8;
            this.person1_Button.Text = "Person 1";
            this.person1_Button.UseVisualStyleBackColor = true;
            this.person1_Button.Click += new System.EventHandler(this.person1_Button_Click);
            // 
            // person2_Button
            // 
            this.person2_Button.Location = new System.Drawing.Point(101, 188);
            this.person2_Button.Name = "person2_Button";
            this.person2_Button.Size = new System.Drawing.Size(75, 23);
            this.person2_Button.TabIndex = 9;
            this.person2_Button.Text = "Person 2";
            this.person2_Button.UseVisualStyleBackColor = true;
            this.person2_Button.Click += new System.EventHandler(this.person2_Button_Click);
            // 
            // person3_Button
            // 
            this.person3_Button.Location = new System.Drawing.Point(183, 188);
            this.person3_Button.Name = "person3_Button";
            this.person3_Button.Size = new System.Drawing.Size(75, 23);
            this.person3_Button.TabIndex = 10;
            this.person3_Button.Text = "Person 3";
            this.person3_Button.UseVisualStyleBackColor = true;
            this.person3_Button.Click += new System.EventHandler(this.person3_Button_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(101, 227);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 11;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 262);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.person3_Button);
            this.Controls.Add(this.person2_Button);
            this.Controls.Add(this.person1_Button);
            this.Controls.Add(this.phoneDisplayLabel);
            this.Controls.Add(this.ageDisplayLabel);
            this.Controls.Add(this.addressDisplayLabel);
            this.Controls.Add(this.nameDisplayLabel);
            this.Controls.Add(this.phoneLabel);
            this.Controls.Add(this.ageLabel);
            this.Controls.Add(this.addressLabel);
            this.Controls.Add(this.nameLabel);
            this.Name = "Form1";
            this.Text = "Personal Information";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label nameLabel;
        private System.Windows.Forms.Label addressLabel;
        private System.Windows.Forms.Label ageLabel;
        private System.Windows.Forms.Label phoneLabel;
        private System.Windows.Forms.Label nameDisplayLabel;
        private System.Windows.Forms.Label addressDisplayLabel;
        private System.Windows.Forms.Label ageDisplayLabel;
        private System.Windows.Forms.Label phoneDisplayLabel;
        private System.Windows.Forms.Button person1_Button;
        private System.Windows.Forms.Button person2_Button;
        private System.Windows.Forms.Button person3_Button;
        private System.Windows.Forms.Button exitButton;
    }
}

