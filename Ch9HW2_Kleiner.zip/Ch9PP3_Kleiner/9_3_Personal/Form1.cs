﻿/*
* 3 May 2018
* CSC 153
* Kenneth Kleiner
* Creating multiple instances of classes.
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _9_3_Personal
{
    public partial class Form1 : Form
    {
        private Person person1 = new Person("Kenneth", "2201 Hull Rd.", 52, "(910) 678-8572");
        private Person person2 = new Person("Michael", "2745 Happy Rd.", 22, "(919) 555-8572");
        private Person person3 = new Person("Thor", "2 Asgard Way", 1505, "(202) 555-8572");
        public Form1()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void person1_Button_Click(object sender, EventArgs e)
        {
            nameDisplayLabel.Text = person1.Name;
            addressDisplayLabel.Text = person1.Address;
            ageDisplayLabel.Text = person1.Age.ToString();
            phoneDisplayLabel.Text = person1.Phone;
        }

        private void person2_Button_Click(object sender, EventArgs e)
        {
            nameDisplayLabel.Text = person2.Name;
            addressDisplayLabel.Text = person2.Address;
            ageDisplayLabel.Text = person2.Age.ToString();
            phoneDisplayLabel.Text = person2.Phone;
        }

        private void person3_Button_Click(object sender, EventArgs e)
        {
            nameDisplayLabel.Text = person3.Name;
            addressDisplayLabel.Text = person3.Address;
            ageDisplayLabel.Text = person3.Age.ToString();
            phoneDisplayLabel.Text = person3.Phone;
        }
    }
}
