﻿namespace M2HW3_Group_3_
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.calculateButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.ticketsGroupBox = new System.Windows.Forms.GroupBox();
            this.cclassTextBox = new System.Windows.Forms.TextBox();
            this.bclassTextBox = new System.Windows.Forms.TextBox();
            this.aclassTextBox = new System.Windows.Forms.TextBox();
            this.cclassSoldLabel = new System.Windows.Forms.Label();
            this.bclassSoldLabel = new System.Windows.Forms.Label();
            this.aclassSoldLabel = new System.Windows.Forms.Label();
            this.inputDescriptionLabel = new System.Windows.Forms.Label();
            this.revenueGroupBox = new System.Windows.Forms.GroupBox();
            this.totalRevenueLabel = new System.Windows.Forms.Label();
            this.bClassLabel = new System.Windows.Forms.Label();
            this.cClassLabel = new System.Windows.Forms.Label();
            this.aClassLabel = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.ticketsGroupBox.SuspendLayout();
            this.revenueGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // calculateButton
            // 
            this.calculateButton.Location = new System.Drawing.Point(42, 167);
            this.calculateButton.Name = "calculateButton";
            this.calculateButton.Size = new System.Drawing.Size(75, 36);
            this.calculateButton.TabIndex = 0;
            this.calculateButton.Text = "Calculate Revenue";
            this.calculateButton.UseVisualStyleBackColor = true;
            this.calculateButton.Click += new System.EventHandler(this.calculateButton_Click);
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(235, 167);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(75, 36);
            this.clearButton.TabIndex = 1;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(416, 167);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 36);
            this.exitButton.TabIndex = 2;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // ticketsGroupBox
            // 
            this.ticketsGroupBox.Controls.Add(this.cclassTextBox);
            this.ticketsGroupBox.Controls.Add(this.bclassTextBox);
            this.ticketsGroupBox.Controls.Add(this.aclassTextBox);
            this.ticketsGroupBox.Controls.Add(this.cclassSoldLabel);
            this.ticketsGroupBox.Controls.Add(this.bclassSoldLabel);
            this.ticketsGroupBox.Controls.Add(this.aclassSoldLabel);
            this.ticketsGroupBox.Controls.Add(this.inputDescriptionLabel);
            this.ticketsGroupBox.Location = new System.Drawing.Point(12, 7);
            this.ticketsGroupBox.Name = "ticketsGroupBox";
            this.ticketsGroupBox.Size = new System.Drawing.Size(270, 149);
            this.ticketsGroupBox.TabIndex = 3;
            this.ticketsGroupBox.TabStop = false;
            this.ticketsGroupBox.Text = "Tickets Sold";
            // 
            // cclassTextBox
            // 
            this.cclassTextBox.Location = new System.Drawing.Point(106, 99);
            this.cclassTextBox.Name = "cclassTextBox";
            this.cclassTextBox.Size = new System.Drawing.Size(100, 20);
            this.cclassTextBox.TabIndex = 6;
            // 
            // bclassTextBox
            // 
            this.bclassTextBox.Location = new System.Drawing.Point(106, 70);
            this.bclassTextBox.Name = "bclassTextBox";
            this.bclassTextBox.Size = new System.Drawing.Size(100, 20);
            this.bclassTextBox.TabIndex = 5;
            // 
            // aclassTextBox
            // 
            this.aclassTextBox.Location = new System.Drawing.Point(106, 44);
            this.aclassTextBox.Name = "aclassTextBox";
            this.aclassTextBox.Size = new System.Drawing.Size(100, 20);
            this.aclassTextBox.TabIndex = 4;
            // 
            // cclassSoldLabel
            // 
            this.cclassSoldLabel.AutoSize = true;
            this.cclassSoldLabel.Location = new System.Drawing.Point(27, 99);
            this.cclassSoldLabel.Name = "cclassSoldLabel";
            this.cclassSoldLabel.Size = new System.Drawing.Size(45, 13);
            this.cclassSoldLabel.TabIndex = 3;
            this.cclassSoldLabel.Text = "Class C:";
            // 
            // bclassSoldLabel
            // 
            this.bclassSoldLabel.AutoSize = true;
            this.bclassSoldLabel.Location = new System.Drawing.Point(27, 70);
            this.bclassSoldLabel.Name = "bclassSoldLabel";
            this.bclassSoldLabel.Size = new System.Drawing.Size(45, 13);
            this.bclassSoldLabel.TabIndex = 2;
            this.bclassSoldLabel.Text = "Class B:";
            // 
            // aclassSoldLabel
            // 
            this.aclassSoldLabel.AutoSize = true;
            this.aclassSoldLabel.Location = new System.Drawing.Point(27, 44);
            this.aclassSoldLabel.Name = "aclassSoldLabel";
            this.aclassSoldLabel.Size = new System.Drawing.Size(45, 13);
            this.aclassSoldLabel.TabIndex = 1;
            this.aclassSoldLabel.Text = "Class A:";
            // 
            // inputDescriptionLabel
            // 
            this.inputDescriptionLabel.AutoSize = true;
            this.inputDescriptionLabel.Location = new System.Drawing.Point(6, 16);
            this.inputDescriptionLabel.Name = "inputDescriptionLabel";
            this.inputDescriptionLabel.Size = new System.Drawing.Size(262, 13);
            this.inputDescriptionLabel.TabIndex = 0;
            this.inputDescriptionLabel.Text = "Enter the number of tickets sold for ech class of seats.";
            // 
            // revenueGroupBox
            // 
            this.revenueGroupBox.Controls.Add(this.totalRevenueLabel);
            this.revenueGroupBox.Controls.Add(this.bClassLabel);
            this.revenueGroupBox.Controls.Add(this.cClassLabel);
            this.revenueGroupBox.Controls.Add(this.aClassLabel);
            this.revenueGroupBox.Controls.Add(this.label4);
            this.revenueGroupBox.Controls.Add(this.label3);
            this.revenueGroupBox.Controls.Add(this.label2);
            this.revenueGroupBox.Controls.Add(this.label1);
            this.revenueGroupBox.Location = new System.Drawing.Point(288, 12);
            this.revenueGroupBox.Name = "revenueGroupBox";
            this.revenueGroupBox.Size = new System.Drawing.Size(270, 149);
            this.revenueGroupBox.TabIndex = 4;
            this.revenueGroupBox.TabStop = false;
            this.revenueGroupBox.Text = "Revenue Generated";
            // 
            // totalRevenueLabel
            // 
            this.totalRevenueLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.totalRevenueLabel.Location = new System.Drawing.Point(103, 121);
            this.totalRevenueLabel.Name = "totalRevenueLabel";
            this.totalRevenueLabel.Size = new System.Drawing.Size(100, 23);
            this.totalRevenueLabel.TabIndex = 7;
            this.totalRevenueLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // bClassLabel
            // 
            this.bClassLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.bClassLabel.Location = new System.Drawing.Point(103, 55);
            this.bClassLabel.Name = "bClassLabel";
            this.bClassLabel.Size = new System.Drawing.Size(100, 23);
            this.bClassLabel.TabIndex = 6;
            this.bClassLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cClassLabel
            // 
            this.cClassLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.cClassLabel.Location = new System.Drawing.Point(103, 89);
            this.cClassLabel.Name = "cClassLabel";
            this.cClassLabel.Size = new System.Drawing.Size(100, 23);
            this.cClassLabel.TabIndex = 5;
            this.cClassLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // aClassLabel
            // 
            this.aClassLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.aClassLabel.Location = new System.Drawing.Point(103, 22);
            this.aClassLabel.Name = "aClassLabel";
            this.aClassLabel.Size = new System.Drawing.Size(100, 23);
            this.aClassLabel.TabIndex = 4;
            this.aClassLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(30, 131);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(34, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Total:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(30, 102);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(45, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Class C:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(30, 65);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(45, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Class B:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(30, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(45, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Class A:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(572, 235);
            this.Controls.Add(this.revenueGroupBox);
            this.Controls.Add(this.ticketsGroupBox);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.calculateButton);
            this.Name = "Form1";
            this.Text = "Stadium Seating";
            this.ticketsGroupBox.ResumeLayout(false);
            this.ticketsGroupBox.PerformLayout();
            this.revenueGroupBox.ResumeLayout(false);
            this.revenueGroupBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button calculateButton;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.GroupBox ticketsGroupBox;
        private System.Windows.Forms.GroupBox revenueGroupBox;
        private System.Windows.Forms.TextBox cclassTextBox;
        private System.Windows.Forms.TextBox bclassTextBox;
        private System.Windows.Forms.TextBox aclassTextBox;
        private System.Windows.Forms.Label cclassSoldLabel;
        private System.Windows.Forms.Label bclassSoldLabel;
        private System.Windows.Forms.Label aclassSoldLabel;
        private System.Windows.Forms.Label inputDescriptionLabel;
        private System.Windows.Forms.Label totalRevenueLabel;
        private System.Windows.Forms.Label bClassLabel;
        private System.Windows.Forms.Label cClassLabel;
        private System.Windows.Forms.Label aClassLabel;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
    }
}

