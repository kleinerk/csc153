﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M2HW3_Group_3_
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
               const decimal classA = 15;
               const decimal classB = 12;
               const decimal classC = 9;

            // Caculation of inputs along with error message
            try
            {
                decimal aSeatPrice;
                decimal bSeatPrice;
                decimal cSeatPrice;
                decimal totalprice;

                // Take input and out put total revenue from each class
                aSeatPrice = int.Parse(aclassTextBox.Text) * classA;
                bSeatPrice = int.Parse(bclassTextBox.Text) * classB;
                cSeatPrice = int.Parse(cclassTextBox.Text) * classC;
                totalprice = (aSeatPrice + bSeatPrice + cSeatPrice);

                // Display the total sales per class
                aClassLabel.Text = aSeatPrice.ToString("c");
                bClassLabel.Text = bSeatPrice.ToString("c");
                cClassLabel.Text = cSeatPrice.ToString("c");

                // Calculate the total revenue from all the classes.
                totalRevenueLabel.Text = totalprice.ToString("c");
            }
            catch (Exception)
            {
                // Display error message
                MessageBox.Show(text:"Please enter a numeric number in all fields");

            }
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            // Clear the display controls.
            aclassTextBox.Text = "";
            bclassTextBox.Text = "";
            cclassTextBox.Text = "";
            aClassLabel.Text = "";
            bClassLabel.Text = "";
            cClassLabel.Text = "";
            totalRevenueLabel.Text = "";
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Close this form.
            this.Close();
        }
    }
}
