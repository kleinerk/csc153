﻿/*
* 10 April 2018
* CSC 153
* Kenneth Kleiner
* This program uses methods to validate data and calculate retirement contributions
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Pay_and_Bonus
{
    public partial class Form1 : Form
    {
        // Constant field for the contribution rate
        private const decimal CONTRIB_RATE = 0.05m;
        public Form1()
        {
            InitializeComponent();
        }

        // the InputIsValidmethod converts the user input and stores
        // it in the arguments (passed by reference). If the conversion
        // is successful, the method returns true. Otherwise it returns
        // false.
        private bool InputIsValid(ref decimal pay, ref decimal bonus)
        {
            // Flag variable to indicate whether the input is good
            bool inputGood = false;

            // try to convert both inputs to decimal
            if (decimal.TryParse(grossPayTextBox.Text, out pay))
            {
                if (decimal.TryParse(bonusTextBox.Text, out bonus))
                {
                    // both inputs are good
                    inputGood = true;
                }
                else
                {
                    // display an error message for the bonus
                    MessageBox.Show("Bonus amount is invalid");
                }
            }
            else
            {
                // display an error message for gross pay
                MessageBox.Show("Gross pay is invalid");
            }
            // return the result
            return inputGood;
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            // variables for gross pay, bonus, and contributions
            decimal grossPay = 0m, bonus = 0m, contributions = 0m;

            if (InputIsValid(ref grossPay, ref bonus))
            {
                // calculate the amount of contribution
                contributions = (grossPay + bonus) * CONTRIB_RATE;

                // display the contribution
                contributionLabel.Text = contributions.ToString("c");
            }
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // close the form
            this.Close();
        }
    }
}
