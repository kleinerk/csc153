﻿/*
* 13 Feb 18
* CSC 153
* Kenneth Kleiner
* This program allows the user to build a sentence
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sentence_Builder
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            resultLabel.Text = "";
        }

        private void upperA_Button_Click(object sender, EventArgs e)
        {
            resultLabel.Text += "A";
        }

        private void lowerA_Button_Click(object sender, EventArgs e)
        {
            resultLabel.Text += "a";
        }

        private void upperTheButton_Click(object sender, EventArgs e)
        {
            resultLabel.Text += "The";
        }

        private void lowerTheButton_Click(object sender, EventArgs e)
        {
            resultLabel.Text += "the";
        }

        private void upperPresidentButton_Click(object sender, EventArgs e)
        {
            resultLabel.Text += "President";
        }

        private void lowerPresidentButton_Click(object sender, EventArgs e)
        {
            resultLabel.Text += "president";
        }

        private void greatButton_Click(object sender, EventArgs e)
        {
            resultLabel.Text += "great";
        }

        private void quotedGreatButton_Click(object sender, EventArgs e)
        {
            resultLabel.Text += "'great'";
        }

        private void doingButton_Click(object sender, EventArgs e)
        {
            resultLabel.Text += "doing";
        }

        private void jobButton_Click(object sender, EventArgs e)
        {
            resultLabel.Text += "job";
        }

        private void upperIsButton_Click(object sender, EventArgs e)
        {
            resultLabel.Text += "Is";
        }

        private void lowerIsButton_Click(object sender, EventArgs e)
        {
            resultLabel.Text += "is";
        }

        private void spaceButton_Click(object sender, EventArgs e)
        {
            resultLabel.Text += " ";
        }

        private void exclamationButton_Click(object sender, EventArgs e)
        {
            resultLabel.Text += "!";
        }

        private void periodButton_Click(object sender, EventArgs e)
        {
            resultLabel.Text += ".";
        }

        private void questionButton_Click(object sender, EventArgs e)
        {
            resultLabel.Text += "?";
        }
    }
}
