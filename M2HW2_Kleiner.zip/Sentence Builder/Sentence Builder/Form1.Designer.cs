﻿namespace Sentence_Builder
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.upperTheButton = new System.Windows.Forms.Button();
            this.lowerTheButton = new System.Windows.Forms.Button();
            this.upperPresidentButton = new System.Windows.Forms.Button();
            this.lowerPresidentButton = new System.Windows.Forms.Button();
            this.upperIsButton = new System.Windows.Forms.Button();
            this.lowerIsButton = new System.Windows.Forms.Button();
            this.doingButton = new System.Windows.Forms.Button();
            this.upperA_Button = new System.Windows.Forms.Button();
            this.greatButton = new System.Windows.Forms.Button();
            this.lowerA_Button = new System.Windows.Forms.Button();
            this.jobButton = new System.Windows.Forms.Button();
            this.exclamationButton = new System.Windows.Forms.Button();
            this.periodButton = new System.Windows.Forms.Button();
            this.questionButton = new System.Windows.Forms.Button();
            this.quotedGreatButton = new System.Windows.Forms.Button();
            this.spaceButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.resultLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // upperTheButton
            // 
            this.upperTheButton.Location = new System.Drawing.Point(495, 28);
            this.upperTheButton.Name = "upperTheButton";
            this.upperTheButton.Size = new System.Drawing.Size(75, 23);
            this.upperTheButton.TabIndex = 0;
            this.upperTheButton.Text = "The";
            this.upperTheButton.UseVisualStyleBackColor = true;
            this.upperTheButton.Click += new System.EventHandler(this.upperTheButton_Click);
            // 
            // lowerTheButton
            // 
            this.lowerTheButton.Location = new System.Drawing.Point(668, 28);
            this.lowerTheButton.Name = "lowerTheButton";
            this.lowerTheButton.Size = new System.Drawing.Size(75, 23);
            this.lowerTheButton.TabIndex = 1;
            this.lowerTheButton.Text = "the";
            this.lowerTheButton.UseVisualStyleBackColor = true;
            this.lowerTheButton.Click += new System.EventHandler(this.lowerTheButton_Click);
            // 
            // upperPresidentButton
            // 
            this.upperPresidentButton.Location = new System.Drawing.Point(108, 76);
            this.upperPresidentButton.Name = "upperPresidentButton";
            this.upperPresidentButton.Size = new System.Drawing.Size(75, 23);
            this.upperPresidentButton.TabIndex = 2;
            this.upperPresidentButton.Text = "President";
            this.upperPresidentButton.UseVisualStyleBackColor = true;
            this.upperPresidentButton.Click += new System.EventHandler(this.upperPresidentButton_Click);
            // 
            // lowerPresidentButton
            // 
            this.lowerPresidentButton.Location = new System.Drawing.Point(310, 76);
            this.lowerPresidentButton.Name = "lowerPresidentButton";
            this.lowerPresidentButton.Size = new System.Drawing.Size(75, 23);
            this.lowerPresidentButton.TabIndex = 3;
            this.lowerPresidentButton.Text = "president";
            this.lowerPresidentButton.UseVisualStyleBackColor = true;
            this.lowerPresidentButton.Click += new System.EventHandler(this.lowerPresidentButton_Click);
            // 
            // upperIsButton
            // 
            this.upperIsButton.Location = new System.Drawing.Point(495, 121);
            this.upperIsButton.Name = "upperIsButton";
            this.upperIsButton.Size = new System.Drawing.Size(75, 23);
            this.upperIsButton.TabIndex = 4;
            this.upperIsButton.Text = "Is";
            this.upperIsButton.UseVisualStyleBackColor = true;
            this.upperIsButton.Click += new System.EventHandler(this.upperIsButton_Click);
            // 
            // lowerIsButton
            // 
            this.lowerIsButton.Location = new System.Drawing.Point(668, 121);
            this.lowerIsButton.Name = "lowerIsButton";
            this.lowerIsButton.Size = new System.Drawing.Size(75, 23);
            this.lowerIsButton.TabIndex = 5;
            this.lowerIsButton.Text = "is";
            this.lowerIsButton.UseVisualStyleBackColor = true;
            this.lowerIsButton.Click += new System.EventHandler(this.lowerIsButton_Click);
            // 
            // doingButton
            // 
            this.doingButton.Location = new System.Drawing.Point(108, 121);
            this.doingButton.Name = "doingButton";
            this.doingButton.Size = new System.Drawing.Size(75, 23);
            this.doingButton.TabIndex = 6;
            this.doingButton.Text = "doing";
            this.doingButton.UseVisualStyleBackColor = true;
            this.doingButton.Click += new System.EventHandler(this.doingButton_Click);
            // 
            // upperA_Button
            // 
            this.upperA_Button.Location = new System.Drawing.Point(108, 28);
            this.upperA_Button.Name = "upperA_Button";
            this.upperA_Button.Size = new System.Drawing.Size(75, 23);
            this.upperA_Button.TabIndex = 7;
            this.upperA_Button.Text = "A";
            this.upperA_Button.UseVisualStyleBackColor = true;
            this.upperA_Button.Click += new System.EventHandler(this.upperA_Button_Click);
            // 
            // greatButton
            // 
            this.greatButton.Location = new System.Drawing.Point(495, 76);
            this.greatButton.Name = "greatButton";
            this.greatButton.Size = new System.Drawing.Size(75, 23);
            this.greatButton.TabIndex = 8;
            this.greatButton.Text = "great";
            this.greatButton.UseVisualStyleBackColor = true;
            this.greatButton.Click += new System.EventHandler(this.greatButton_Click);
            // 
            // lowerA_Button
            // 
            this.lowerA_Button.Location = new System.Drawing.Point(310, 28);
            this.lowerA_Button.Name = "lowerA_Button";
            this.lowerA_Button.Size = new System.Drawing.Size(75, 23);
            this.lowerA_Button.TabIndex = 9;
            this.lowerA_Button.Text = "a";
            this.lowerA_Button.UseVisualStyleBackColor = true;
            this.lowerA_Button.Click += new System.EventHandler(this.lowerA_Button_Click);
            // 
            // jobButton
            // 
            this.jobButton.Location = new System.Drawing.Point(310, 121);
            this.jobButton.Name = "jobButton";
            this.jobButton.Size = new System.Drawing.Size(75, 23);
            this.jobButton.TabIndex = 10;
            this.jobButton.Text = "job";
            this.jobButton.UseVisualStyleBackColor = true;
            this.jobButton.Click += new System.EventHandler(this.jobButton_Click);
            // 
            // exclamationButton
            // 
            this.exclamationButton.Location = new System.Drawing.Point(310, 160);
            this.exclamationButton.Name = "exclamationButton";
            this.exclamationButton.Size = new System.Drawing.Size(75, 23);
            this.exclamationButton.TabIndex = 11;
            this.exclamationButton.Text = "!";
            this.exclamationButton.UseVisualStyleBackColor = true;
            this.exclamationButton.Click += new System.EventHandler(this.exclamationButton_Click);
            // 
            // periodButton
            // 
            this.periodButton.Location = new System.Drawing.Point(495, 160);
            this.periodButton.Name = "periodButton";
            this.periodButton.Size = new System.Drawing.Size(75, 23);
            this.periodButton.TabIndex = 12;
            this.periodButton.Text = ".";
            this.periodButton.UseVisualStyleBackColor = true;
            this.periodButton.Click += new System.EventHandler(this.periodButton_Click);
            // 
            // questionButton
            // 
            this.questionButton.Location = new System.Drawing.Point(668, 161);
            this.questionButton.Name = "questionButton";
            this.questionButton.Size = new System.Drawing.Size(75, 23);
            this.questionButton.TabIndex = 13;
            this.questionButton.Text = "?";
            this.questionButton.UseVisualStyleBackColor = true;
            this.questionButton.Click += new System.EventHandler(this.questionButton_Click);
            // 
            // quotedGreatButton
            // 
            this.quotedGreatButton.Location = new System.Drawing.Point(668, 76);
            this.quotedGreatButton.Name = "quotedGreatButton";
            this.quotedGreatButton.Size = new System.Drawing.Size(75, 23);
            this.quotedGreatButton.TabIndex = 14;
            this.quotedGreatButton.Text = "\'great\'";
            this.quotedGreatButton.UseVisualStyleBackColor = true;
            this.quotedGreatButton.Click += new System.EventHandler(this.quotedGreatButton_Click);
            // 
            // spaceButton
            // 
            this.spaceButton.Location = new System.Drawing.Point(108, 160);
            this.spaceButton.Name = "spaceButton";
            this.spaceButton.Size = new System.Drawing.Size(75, 23);
            this.spaceButton.TabIndex = 15;
            this.spaceButton.Text = "(Space)";
            this.spaceButton.UseVisualStyleBackColor = true;
            this.spaceButton.Click += new System.EventHandler(this.spaceButton_Click);
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(310, 271);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(75, 23);
            this.clearButton.TabIndex = 16;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(495, 271);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 17;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // resultLabel
            // 
            this.resultLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.resultLabel.Location = new System.Drawing.Point(108, 217);
            this.resultLabel.Name = "resultLabel";
            this.resultLabel.Size = new System.Drawing.Size(635, 34);
            this.resultLabel.TabIndex = 18;
            this.resultLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(945, 306);
            this.Controls.Add(this.resultLabel);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.spaceButton);
            this.Controls.Add(this.quotedGreatButton);
            this.Controls.Add(this.questionButton);
            this.Controls.Add(this.periodButton);
            this.Controls.Add(this.exclamationButton);
            this.Controls.Add(this.jobButton);
            this.Controls.Add(this.lowerA_Button);
            this.Controls.Add(this.greatButton);
            this.Controls.Add(this.upperA_Button);
            this.Controls.Add(this.doingButton);
            this.Controls.Add(this.lowerIsButton);
            this.Controls.Add(this.upperIsButton);
            this.Controls.Add(this.lowerPresidentButton);
            this.Controls.Add(this.upperPresidentButton);
            this.Controls.Add(this.lowerTheButton);
            this.Controls.Add(this.upperTheButton);
            this.Name = "Form1";
            this.Text = "Sentence Builder";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button upperTheButton;
        private System.Windows.Forms.Button lowerTheButton;
        private System.Windows.Forms.Button upperPresidentButton;
        private System.Windows.Forms.Button lowerPresidentButton;
        private System.Windows.Forms.Button upperIsButton;
        private System.Windows.Forms.Button lowerIsButton;
        private System.Windows.Forms.Button doingButton;
        private System.Windows.Forms.Button upperA_Button;
        private System.Windows.Forms.Button greatButton;
        private System.Windows.Forms.Button lowerA_Button;
        private System.Windows.Forms.Button jobButton;
        private System.Windows.Forms.Button exclamationButton;
        private System.Windows.Forms.Button periodButton;
        private System.Windows.Forms.Button questionButton;
        private System.Windows.Forms.Button quotedGreatButton;
        private System.Windows.Forms.Button spaceButton;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Label resultLabel;
    }
}

