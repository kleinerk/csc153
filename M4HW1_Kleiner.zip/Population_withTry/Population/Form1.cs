﻿/*
* 6 March 2018
* CSC 153
* Kenneth Kleiner
* Population growth calculator
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Population
{
    public partial class Form1: Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Exit form
            this.Close();
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            // Clear form inputs
            populationTextBox.Text = "";
            growthTextBox.Text = "";
            timeTextBox.Text = "";

            // Clear form results
            resultsListBox.Items.Clear();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            try
            {
                // Get inputs for calculation
                double startPopulation = double.Parse(populationTextBox.Text);
                double growthRate = double.Parse(growthTextBox.Text);
                int timeDuration = int.Parse(timeTextBox.Text);

                int timeValue = 1;
                int prevTimeValue = 0;
                double populationValue = startPopulation;

                // Do first calculation
                populationValue = startPopulation;
                resultsListBox.Items.Add(populationValue);

                // Do rest of calculations
                while (timeValue < timeDuration)
                {
                    populationValue = populationValue + (populationValue * (growthRate / 100)) * (timeValue - prevTimeValue);
                    // Add result to ListBox
                    resultsListBox.Items.Add(populationValue);
                    timeValue++;
                    prevTimeValue++;
                }
            }
            catch (Exception ex)
            {
                // Display an error message
                MessageBox.Show(ex.Message);
            }
        }
    }
}
