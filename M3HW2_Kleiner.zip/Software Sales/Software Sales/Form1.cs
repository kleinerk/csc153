﻿/*
* 21 February 2018
* CSC 153
* Kenneth Kleiner
* Software sales 4-7
* Depending on number of units being bought, discount amount changes
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Software_Sales
{
    public partial class softwareSalesForm : Form
    {
        public softwareSalesForm()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Close application
            this.Close();
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            unitsBoughtTextBox.Text = "";   // reset input box
            retailValueLabel.Text = "";     // reset retail value
            discountAmountLabel.Text = "";  // reset discount value
            totalPriceLabel.Text = "";      // reset total price

            // Send focus to input box
            unitsBoughtTextBox.Focus();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            // named constants
            const decimal RETAIL_PRICE = 99.00m;

            // local variables
            int unitsBought;        // Number of units being purchased
            decimal retailValue;    // retail value of purchase (without discount)
            decimal discountRate;   // discount rate
            decimal discountValue;  // discount amount
            decimal totalPrice;     // price with any discount amount

            // get units being purchased
            unitsBought = int.Parse(unitsBoughtTextBox.Text);

            // determine discount rate
            if (unitsBought >= 100)
            {
                discountRate = 0.50m;
            }
            else if (unitsBought >= 50)
            {
                discountRate = 0.40m;
            }
            else if (unitsBought >= 20)
            {
                discountRate = 0.30m;
            }
            else if (unitsBought >= 10)
            {
                discountRate = 0.20m;
            }
            else
            {
                // no discount given
                discountRate = 0.00m;
            }

            // calculate retail price
            retailValue = unitsBought * RETAIL_PRICE;

            // calculate discount amount
            discountValue = unitsBought * RETAIL_PRICE * discountRate;

            // calculate total price
            totalPrice = retailValue - discountValue;

            // display results
            retailValueLabel.Text = retailValue.ToString("c");
            discountAmountLabel.Text = discountValue.ToString("c");
            totalPriceLabel.Text = totalPrice.ToString("c");
        }
    }
}
