﻿namespace Software_Sales
{
    partial class softwareSalesForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.unitsBoughtTextBox = new System.Windows.Forms.TextBox();
            this.instructionLabel = new System.Windows.Forms.Label();
            this.retailLabel = new System.Windows.Forms.Label();
            this.discountLabel = new System.Windows.Forms.Label();
            this.totalLabel = new System.Windows.Forms.Label();
            this.retailValueLabel = new System.Windows.Forms.Label();
            this.discountAmountLabel = new System.Windows.Forms.Label();
            this.totalPriceLabel = new System.Windows.Forms.Label();
            this.clearButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.calculateButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // unitsBoughtTextBox
            // 
            this.unitsBoughtTextBox.Location = new System.Drawing.Point(234, 28);
            this.unitsBoughtTextBox.Name = "unitsBoughtTextBox";
            this.unitsBoughtTextBox.Size = new System.Drawing.Size(100, 20);
            this.unitsBoughtTextBox.TabIndex = 0;
            // 
            // instructionLabel
            // 
            this.instructionLabel.AutoSize = true;
            this.instructionLabel.Location = new System.Drawing.Point(12, 31);
            this.instructionLabel.Name = "instructionLabel";
            this.instructionLabel.Size = new System.Drawing.Size(174, 13);
            this.instructionLabel.TabIndex = 1;
            this.instructionLabel.Text = "Input number of units being bought:";
            // 
            // retailLabel
            // 
            this.retailLabel.AutoSize = true;
            this.retailLabel.Location = new System.Drawing.Point(119, 79);
            this.retailLabel.Name = "retailLabel";
            this.retailLabel.Size = new System.Drawing.Size(67, 13);
            this.retailLabel.TabIndex = 2;
            this.retailLabel.Text = "Retail Value:";
            // 
            // discountLabel
            // 
            this.discountLabel.AutoSize = true;
            this.discountLabel.Location = new System.Drawing.Point(95, 116);
            this.discountLabel.Name = "discountLabel";
            this.discountLabel.Size = new System.Drawing.Size(91, 13);
            this.discountLabel.TabIndex = 3;
            this.discountLabel.Text = "Discount Amount:";
            // 
            // totalLabel
            // 
            this.totalLabel.AutoSize = true;
            this.totalLabel.Location = new System.Drawing.Point(125, 157);
            this.totalLabel.Name = "totalLabel";
            this.totalLabel.Size = new System.Drawing.Size(61, 13);
            this.totalLabel.TabIndex = 4;
            this.totalLabel.Text = "Total Price:";
            // 
            // retailValueLabel
            // 
            this.retailValueLabel.BackColor = System.Drawing.SystemColors.Info;
            this.retailValueLabel.Location = new System.Drawing.Point(231, 74);
            this.retailValueLabel.Name = "retailValueLabel";
            this.retailValueLabel.Size = new System.Drawing.Size(100, 23);
            this.retailValueLabel.TabIndex = 5;
            this.retailValueLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // discountAmountLabel
            // 
            this.discountAmountLabel.BackColor = System.Drawing.SystemColors.Info;
            this.discountAmountLabel.Location = new System.Drawing.Point(231, 116);
            this.discountAmountLabel.Name = "discountAmountLabel";
            this.discountAmountLabel.Size = new System.Drawing.Size(100, 23);
            this.discountAmountLabel.TabIndex = 6;
            this.discountAmountLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // totalPriceLabel
            // 
            this.totalPriceLabel.BackColor = System.Drawing.SystemColors.Info;
            this.totalPriceLabel.Location = new System.Drawing.Point(231, 152);
            this.totalPriceLabel.Name = "totalPriceLabel";
            this.totalPriceLabel.Size = new System.Drawing.Size(100, 23);
            this.totalPriceLabel.TabIndex = 7;
            this.totalPriceLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(128, 214);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(75, 23);
            this.clearButton.TabIndex = 8;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(259, 214);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 9;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // calculateButton
            // 
            this.calculateButton.Location = new System.Drawing.Point(359, 28);
            this.calculateButton.Name = "calculateButton";
            this.calculateButton.Size = new System.Drawing.Size(75, 43);
            this.calculateButton.TabIndex = 10;
            this.calculateButton.Text = "Calculate Price";
            this.calculateButton.UseVisualStyleBackColor = true;
            this.calculateButton.Click += new System.EventHandler(this.calculateButton_Click);
            // 
            // softwareSalesForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(466, 260);
            this.Controls.Add(this.calculateButton);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.totalPriceLabel);
            this.Controls.Add(this.discountAmountLabel);
            this.Controls.Add(this.retailValueLabel);
            this.Controls.Add(this.totalLabel);
            this.Controls.Add(this.discountLabel);
            this.Controls.Add(this.retailLabel);
            this.Controls.Add(this.instructionLabel);
            this.Controls.Add(this.unitsBoughtTextBox);
            this.Name = "softwareSalesForm";
            this.Text = "Software Sales";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox unitsBoughtTextBox;
        private System.Windows.Forms.Label instructionLabel;
        private System.Windows.Forms.Label retailLabel;
        private System.Windows.Forms.Label discountLabel;
        private System.Windows.Forms.Label totalLabel;
        private System.Windows.Forms.Label retailValueLabel;
        private System.Windows.Forms.Label discountAmountLabel;
        private System.Windows.Forms.Label totalPriceLabel;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Button calculateButton;
    }
}

