﻿/*
* 6 March 2018
* CSC 153
* Kenneth Kleiner
* Random number / dice game
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dice_Simulator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void rollDiceButton_Click(object sender, EventArgs e)
        {
            int dieOne;
            int dieTwo;

            Random rand = new Random();
            dieOne = rand.Next(6) + 1;
            dieTwo = rand.Next(6) + 1;

            switch (dieOne)
            {
                case 1:
                    dieOnePictureBox.Image = global::Dice_Simulator.Properties.Resources.Die1;
                    break;
                case 2:
                    dieOnePictureBox.Image = global::Dice_Simulator.Properties.Resources.Die2;
                    break;
                case 3:
                    dieOnePictureBox.Image = global::Dice_Simulator.Properties.Resources.Die3;
                    break;
                case 4:
                    dieOnePictureBox.Image = global::Dice_Simulator.Properties.Resources.Die4;
                    break;
                case 5:
                    dieOnePictureBox.Image = global::Dice_Simulator.Properties.Resources.Die5;
                    break;
                case 6:
                    dieOnePictureBox.Image = global::Dice_Simulator.Properties.Resources.Die6;
                    break;
            }

            switch (dieTwo)
            {
                case 1:
                    dieTwoPictureBox.Image = global::Dice_Simulator.Properties.Resources.Die1;
                    break;
                case 2:
                    dieTwoPictureBox.Image = global::Dice_Simulator.Properties.Resources.Die2;
                    break;
                case 3:
                    dieTwoPictureBox.Image = global::Dice_Simulator.Properties.Resources.Die3;
                    break;
                case 4:
                    dieTwoPictureBox.Image = global::Dice_Simulator.Properties.Resources.Die4;
                    break;
                case 5:
                    dieTwoPictureBox.Image = global::Dice_Simulator.Properties.Resources.Die5;
                    break;
                case 6:
                    dieTwoPictureBox.Image = global::Dice_Simulator.Properties.Resources.Die6;
                    break;
            }


        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //  exit form
            this.Close();
        }
    }
}
