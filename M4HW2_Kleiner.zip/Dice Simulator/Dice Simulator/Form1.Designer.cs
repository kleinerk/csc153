﻿namespace Dice_Simulator
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rollDiceButton = new System.Windows.Forms.Button();
            this.dieOnePictureBox = new System.Windows.Forms.PictureBox();
            this.dieTwoPictureBox = new System.Windows.Forms.PictureBox();
            this.exitButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dieOnePictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dieTwoPictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // rollDiceButton
            // 
            this.rollDiceButton.Location = new System.Drawing.Point(283, 108);
            this.rollDiceButton.Name = "rollDiceButton";
            this.rollDiceButton.Size = new System.Drawing.Size(75, 23);
            this.rollDiceButton.TabIndex = 0;
            this.rollDiceButton.Text = "Roll Dice";
            this.rollDiceButton.UseVisualStyleBackColor = true;
            this.rollDiceButton.Click += new System.EventHandler(this.rollDiceButton_Click);
            // 
            // dieOnePictureBox
            // 
            this.dieOnePictureBox.Image = global::Dice_Simulator.Properties.Resources.Die6;
            this.dieOnePictureBox.Location = new System.Drawing.Point(151, 65);
            this.dieOnePictureBox.Name = "dieOnePictureBox";
            this.dieOnePictureBox.Size = new System.Drawing.Size(104, 103);
            this.dieOnePictureBox.TabIndex = 1;
            this.dieOnePictureBox.TabStop = false;
            // 
            // dieTwoPictureBox
            // 
            this.dieTwoPictureBox.Image = global::Dice_Simulator.Properties.Resources.Die6;
            this.dieTwoPictureBox.Location = new System.Drawing.Point(385, 65);
            this.dieTwoPictureBox.Name = "dieTwoPictureBox";
            this.dieTwoPictureBox.Size = new System.Drawing.Size(105, 103);
            this.dieTwoPictureBox.TabIndex = 2;
            this.dieTwoPictureBox.TabStop = false;
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(283, 192);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 3;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(663, 322);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.dieTwoPictureBox);
            this.Controls.Add(this.dieOnePictureBox);
            this.Controls.Add(this.rollDiceButton);
            this.Name = "Form1";
            this.Text = "Dice Simulator";
            ((System.ComponentModel.ISupportInitialize)(this.dieOnePictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dieTwoPictureBox)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button rollDiceButton;
        private System.Windows.Forms.PictureBox dieOnePictureBox;
        private System.Windows.Forms.PictureBox dieTwoPictureBox;
        private System.Windows.Forms.Button exitButton;
    }
}

