﻿/*
* 3 May 2018
* CSC 153
* Kenneth Kleiner
* Creating a class from scratch
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _9_1_Pet
{
    public partial class Form1: Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void GetPetData(Pet inputPet)
        {
            int age;

            inputPet.Name = nameTextBox.Text;
            inputPet.Type = typeTextBox.Text;
            if (int.TryParse(ageTextBox.Text, out age))
            {
                inputPet.Age = age;
            }
            else
            {
                MessageBox.Show("Invalid Age");
            }
        }

        private void addDataButton_Click(object sender, EventArgs e)
        {
            if (nameTextBox.Text == "" || typeTextBox.Text == "" || ageTextBox.Text == "0")
            {
                MessageBox.Show("Error in data entry");
            }
            else
            {
                Pet myPet = new Pet();

                GetPetData(myPet);

                nameOutLabel.Text = myPet.Name;
                typeOutLabel.Text = myPet.Type;
                ageOutLabel.Text = myPet.Age.ToString();
            }
        }
    }
}
