﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _9_1_Pet
{
    class Pet
    {
        // Fields for pet information
        private string _name;
        private string _type;
        private int _age;

        // Constructor
        public Pet()
        {
            _name = "";
            _type = "";
            _age = 0;
        }

        // Name property
        public string Name
        {
            get
            {
                return _name;
            }

            set
            {
                _name = value;
            }
        }

        // Type property
        public string Type
        {
            get
            {
                return _type;
            }

            set
            {
                _type = value;
            }
        }

        // Age property
        public int Age
        {
            get
            {
                return _age;
            }

            set
            {
                _age = value;
            }
        }
    }
}
