﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _9_2_Car
{
    class Car
    {
        private string _make;
        private string _year;
        private int _speed;

        // Constructor
        public Car(string make, string year)
        {
            _make = make;
            _year = year;
            _speed = 0;
        }

        public string Make
        {
            get { return _make; }
            set { _make = value; }
        }

        public string Year
        {
            get { return _year; }
            set { _year = value; }
        }

        public int CurrentSpeed
        {
            get { return _speed; }
        }

        public void Accelerate()
        {
            _speed += 5;
        }

        public void Brake()
        {
            _speed -= 5;
        }
    }
}
