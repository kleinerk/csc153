﻿/*
* 3 May 2018
* CSC 153
* Kenneth Kleiner
* Updating information in a class via buttons
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _9_2_Car
{
    public partial class Form1 : Form
    {
        private Car car = new Car("Ford", "2000");
        public Form1()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void accelerateButton_Click(object sender, EventArgs e)
        {
            makeTextBox.Text = car.Make;
            yearTextBox.Text = car.Year;
            car.Accelerate();
            speedDisplayLabel.Text = car.CurrentSpeed.ToString();
        }

        private void brakeButton_Click(object sender, EventArgs e)
        {
            makeTextBox.Text = car.Make;
            yearTextBox.Text = car.Year;
            car.Brake();
            speedDisplayLabel.Text = car.CurrentSpeed.ToString();
        }
    }
}
